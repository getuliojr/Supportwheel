﻿///////////////////////////////////////////////////////////////////////////
////// POR FAVOR CRIE NOVAS CONSTANTES INSERINDO EM ORDEM ALFABÉTICA /////
//////  CONFIRME QUE A CONSTANTE AINDA NÃO EXISTE                    /////
//////////////////////////////////////////////////////////////////////////

(function () {

    'use strict';

    angular.module('modules.common.services.value.constantes', [

    ])

    .value("constEventosDb",
        {
            "INSERIDO": 1, "ATUALIZADO": 2, "REMOVIDO": 3, "CARREGADO": 4
        });
})();






