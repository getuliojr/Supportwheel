﻿(function () {

    'use strict';

    angular.module('modules.common.services.provider', [
       'modules.common.services.provider.authorization'
    ]);

})();