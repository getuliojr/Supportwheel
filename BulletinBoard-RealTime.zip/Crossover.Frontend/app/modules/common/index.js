﻿angular.module('modules.common', [
    'modules.common.services'

])