﻿(function () {

    'use strict';

    //Define o módulo
    angular
        .module('modules', [
            'modules.comment',
            'modules.common',
            'modules.topic'
        ]);
 
})();

