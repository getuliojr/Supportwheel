﻿(function () {

    'use strict';

    angular.module('modules.comment.services', [
        'modules.comment.services.service'
    ]);

})();