﻿angular.module('directives', [
    'directives.restrict',
    'directives.msgConfirm',
    'directives.listComments',
    'directives.addComment',
    'directives.animateOnLoad',
    'directives.auth',
    'directives.authenticatedMenu',
    'directives.compareTo'
]);