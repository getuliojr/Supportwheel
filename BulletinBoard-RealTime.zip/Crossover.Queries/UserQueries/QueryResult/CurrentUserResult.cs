﻿using System;
using System.Collections.Generic;

namespace Crossover.Queries.UserQueries.QueryResult
{
    public class CurrentUserResult
    {
      
        public int intIdUser { get; set; }
        public string strFullName { get; set; }
        public string strEmail { get; set; }

    }



}