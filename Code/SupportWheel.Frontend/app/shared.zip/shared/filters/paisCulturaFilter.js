﻿(function () {
    'use strict';

    angular
        .module('shared.filters.paisCultura', [
            'shared.services.service.pais',
            'shared.services.service.culture',
        ])

        .filter('paisCultura', paisCulturaFilter);


    paisCulturaFilter.$inject = ['paisService', 'cultureService'];

    function paisCulturaFilter(paisService, cultureService) {

        return function (intIdPais) {

            paisService.load({ cache: true }).then(function (result) {
                var currentCulture = cultureService.getCulture();

                if (currentCulture == undefined) {
                    currentCulture = "pt-BR";
                } else {
                    currentCulture = cultureService.strIdCultura;
                }

                return _.find(result, {'strIdCultura': currentCulture, 'intIdPais': intIdPais}).strNomePais;
            });
        };

    }
})();