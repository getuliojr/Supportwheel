﻿describe('Filter: paisCultura - ', function () {
    'use strict';

    //Variable for itens that are going to be used in the tests
    var paisCulturaFilter;

    //Load Module to be Tested
    beforeEach(module('shared.filters.paisCultura'));

    //Inject Dependencies
    beforeEach(inject(function (_paisCulturaFilter_) {
        paisCulturaFilter = _paisCulturaFilter_;
    }));

    it('expect to return the name of the country filtering by intIdPais property', function () {
        var countries = [
           { 'intIdPais': 1, 'strNomePais': 'PAIS TESTE 01' },
           { 'intIdPais': 2, 'strNomePais': 'PAIS TESTE 02' },
           { 'intIdPais': 3, 'strNomePais': 'PAIS TESTE 03' }
        ];

        expect(paisCulturaFilter(countries, 2)).toEqual('PAIS TESTE 02');
        expect(paisCulturaFilter(countries, 3)).toEqual('PAIS TESTE 03');
    });

});