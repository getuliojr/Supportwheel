﻿(function () {

    'use strict';

    angular.module('ASAMapApp').config(rotas);

    rotas.$inject = ['$stateProvider'];

    function rotas($stateProvider) {

        $stateProvider
            .state('public', { //Tabs - Defaults to list
                url: '/project',
                abstract: true,
                views:{
                    '@': {
                        template: '<create-tabs title="create.title" tabs="create.tabs" current-tab-index="$resolve.tab.index" current-view="$resolve.current"></create-tabs />',
                        resolve: {
                            tabs: function () {
                                return [{ tabName: "TABS.PROJECT.SEARCH", tabIcon: "search", tabViewName: "search", tabStates: ["public.search"] },
                                    { tabName: "TABS.PROJECT.PROJECT", tabIcon: "note_add", tabViewName: "project", tabStates: ["public", "public.project", "public.view", "public.view.index"] }
                                ];
                            },
                            title: function () { return "TABS.PROJECT.TITLE"; }
                        },
                        controller: function (tabs, title) {
                            var vm = this;
                            vm.tabs = tabs;
                            vm.title = title;
                        },
                        controllerAs: 'create'
                    }
                    
                },
                requireAuthenticatedUser: false
               
            })

            .state('public.search', {
                url: '/search',
                views: {
                    'search': {
                        template: '<abc-projeto-search></abc-projeto-search>'
                    },
                    'project': {
                        template: '{{ "TABS.PROJECT.SELECT-PROJECT" | translate }}'
                    }
                }
            })
            .state('public.project', {
                url: '',
                views: {
                    'search': {
                        template: '<abc-projeto-search></abc-projeto-search>'
                    },
                    'project': {
                        template: '{{ "TABS.PROJECT.SELECT-PROJECT" | translate }}'
                    }
                }
            })

            .state('public.view', //Visualizar registro (atualizar e apagar)
            {
                url: '/{id:[0-9]*}',
                abstract: true,
                views: {
                    'search': {
                        template: '<abc-projeto-search></abc-projeto-search>'
                    },
                    'project': {
                        template: '<ui-view/>'
                        
                    }
                }
            })

            .state('public.view.index', //Visualizar 
            {
                url: '',
                template: '<abc-projeto-view id="$resolve.projeto"></abc-projeto-view>',

                resolve: {
                    projeto: ['$stateParams', function ($stateParams) {
                        return $stateParams.id
                    }]
                }
              
            })
        

    }

})();