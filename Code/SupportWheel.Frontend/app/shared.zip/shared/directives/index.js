﻿angular.module('shared.directives', [
    'shared.directives.restrict',
    'shared.directives.msgConfirm',
    'shared.directives.animateOnLoad',
    'shared.directives.compareTo'
]);