﻿(function () {

    'use strict';

    angular
        .module('shared.services', [
            'shared.services.factory',
            'shared.services.provider',
            'shared.services.service',
            'shared.services.value'
        ]);

})();