﻿///////////////////////////////////////////////////////////////////////////
////// POR FAVOR CRIE NOVAS CONSTANTES INSERINDO EM ORDEM ALFABÉTICA /////
//////  CONFIRME QUE A CONSTANTE AINDA NÃO EXISTE                    /////
//////////////////////////////////////////////////////////////////////////

(function () {

    'use strict';

    angular.module('shared.services.value.constantes', [
        ])
        .value("constEventosDb",
        {
            "INSERTED": 1,
            "UPDATED": 2,
            "DELETED": 3
        });

})();






