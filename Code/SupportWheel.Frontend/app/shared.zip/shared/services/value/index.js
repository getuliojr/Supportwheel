﻿(function () {

    'use strict';

    angular.module('shared.services.value', [
        'shared.services.value.constantes'
    ]);

})();