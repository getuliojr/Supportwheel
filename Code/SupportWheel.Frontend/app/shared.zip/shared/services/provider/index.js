﻿(function () {

    'use strict';

    angular.module('shared.services.provider', [
       'shared.services.provider.authorization'
    ]);

})();