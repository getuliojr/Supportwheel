﻿(function() {

    'use strict';

    angular
        .module('shared.services.service.instituicao', [
            'shared.services.factory.appResource'
        ])
        .service('instituicaoService', instituicaoService);

    instituicaoService.$inject = ['appResourceFactory'];

    function instituicaoService(appResourceFactory) {

        var service = appResourceFactory('instituicao', 'intIdInstituicao');
        service.createHub();

        service.validate = function(dados) {
            var erros = [];

            if (!dados.strNomeInstituicao)
                erros.push('É necessário informar o nome da instituição.');

            if (!dados.intIdPais)
                erros.push('É necessário informar um país para a instituição.');

            return erros;
        };

        return service;
    }
})();