﻿(function() {

    'use strict';

    angular
        .module('shared.services.service.pais', [
            'shared.services.factory.appResource'
        ])
        .service('paisService', paisService);

    paisService.$inject = ['appResourceFactory'];

    function paisService(appResourceFactory) {

        var service = appResourceFactory('pais', 'intIdPais');
               
        return service;
    }
})();