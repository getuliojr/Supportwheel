﻿(function () {

    'use strict';

    /**
     * @ngdoc service
     * @name shared.services.service.service:organismo
     *
     * @requires shared.services.factory.service:appResource
     *
     * @description
     *
     * This service is responsable to make the interface of the application with the database for the table 'Organismo Internacional'
     *
     */
    angular.module('shared.services.service.organismo', [
        'shared.services.factory.appResource'
        ])
        .service('organismoService', organismoService);

    //Inject the dependencies
    organismoService.$inject = ['appResourceFactory'];

    //Create the service
    function organismoService(appResourceFactory) {

        var service = appResourceFactory("organismointernacional", "intIdOrganismoInternacional");

        return service;
    }
})()