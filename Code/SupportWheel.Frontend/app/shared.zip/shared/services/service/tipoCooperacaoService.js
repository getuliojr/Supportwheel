﻿(function() {

    'use strict';

    /**
     * @ngdoc service
     * @name shared.services.service.service:tipoCooperacaoService
     *
     * @description
     *
     * This service is responsable to return the 'tipos de Cooperacao' collection with its value set with the current culture
     * It does not go to the backend, since the list is really small the collection is populated in the front-end.
     *
     */
    angular.module('shared.services.service.tipoCooperacao', [
            'shared.services.factory.appResource'
        ])
        .service('tipoCooperacaoService', tipoCooperacaoService);

    tipoCooperacaoService.$inject = ['$translate', '$q'];

    function tipoCooperacaoService($translate, $q) {

        /**
       
        * @ngdoc function
        * @name load
        * @methodOf shared.services.service.service:tipoCooperacaoService
        * @private
        *
        * @description
        *
        * It returns the collection 'tipos de Cooperacao' with its value set with the current culture.
        *
        */
        this.load = function () {
            //Since it is just a small list there is no need to go to the backend to get the results
            var data =  [
                { intIdTipoCooperacao: 1, strNomeTipoCooperacao: 'TIPOCOOPERACAO.REGIONAL' },
                { intIdTipoCooperacao: 2, strNomeTipoCooperacao: 'TIPOCOOPERACAO.BILATERAL' },
                { intIdTipoCooperacao: 3, strNomeTipoCooperacao: 'TIPOCOOPERACAO.TRILATERAL' }
            ]
            
            var deferred = $q.defer();
            //Wait initial loading of a culture.json file
            $translate.onReady(function () {
                angular.forEach(data, function (val, key) {
                    data[key].strNomeTipoCooperacao = $translate.instant(data[key].strNomeTipoCooperacao);
                });

                deferred.resolve(data);
            });

            return deferred.promise;

        }

    }
})();