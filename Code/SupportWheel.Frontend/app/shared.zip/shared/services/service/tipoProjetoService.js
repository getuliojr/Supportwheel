﻿(function() {

    'use strict';

    /**
     * @ngdoc service
     * @name shared.services.service.service:tipoProjeto
     *
     * @description
     *
     * This service is responsable to return the 'tipoProjeto' collection with its value set with the current culture
     * It does not go to the backend, since the list is really small the collection is populated in the front-end.
     *
     */
    angular.module('shared.services.service.tipoProjeto', [
            'shared.services.factory.appResource'
        ])
        .service('tipoProjetoService', tipoProjetoService);

    tipoProjetoService.$inject = ['$translate', '$q'];

    function tipoProjetoService($translate, $q) {

        /**
       
        * @ngdoc function
        * @name load
        * @methodOf shared.services.service.service:tipoProjeto
        * @private
        *
        * @description
        *
        * It returns the collection 'tipoProjeto' with its value set with the current culture.
        *
        */
        this.load = function () {
            //Since it is just a small list there is no need to go to the backend to get the results
            var data =  [
                { intIdTipoProjeto: 1, strNomeTipoProjeto: 'TIPOPROJETO.PROGRAMA' },
                { intIdTipoProjeto: 2, strNomeTipoProjeto: 'TIPOPROJETO.PROJETO' },
                { intIdTipoProjeto: 3, strNomeTipoProjeto: 'TIPOPROJETO.ATIVIDADE' }
            ]
            
            var deferred = $q.defer();
            //Wait initial loading of a culture.json file
            $translate.onReady(function () {
                angular.forEach(data, function (val, key) {
                    data[key].strNomeTipoProjeto = $translate.instant(data[key].strNomeTipoProjeto);
                });

                deferred.resolve(data);
            });

            return deferred.promise;

        }

    }
})();