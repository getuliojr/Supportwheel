﻿describe('Shared.Services.Service: tipoCooperacao', function () {

    //Variable for itens that are going to be used in the tests
    var tipoCooperacaoService, $translate, $rootScope;

    //Load Services
    beforeEach(module('shared.services.service', 'ngStorage', 'ngMaterial', 'pascalprecht.translate'));

    //Fake translation values
    beforeEach(module(function ($translateProvider) {
        $translateProvider.translations('en', { 'TIPOCOOPERACAO.REGIONAL': 'Region' });
        $translateProvider.translations('pt', { 'TIPOCOOPERACAO.REGIONAL': 'Regional' });
    }));

    //Inject Dependencies
    beforeEach(inject(function (_tipoCooperacaoService_, _$translate_, _$rootScope_) {

        //Create new scope
        tipoCooperacaoService = _tipoCooperacaoService_;
        $translate = _$translate_;
        $rootScope = _$rootScope_;

        //Set to a non existent culture, so it does not interfere with tests
        $translate.use('xx');

    }));


    it('expect service to be defined', function () {
        expect(tipoCooperacaoService).toBeDefined();
        expect(tipoCooperacaoService.load).toBeDefined();
        
    });


    it('expect service to return 3 itens', function () {
        var data = [];
        tipoCooperacaoService.load()
            .then(function (result) {
                data = result;
            });
        $rootScope.$digest();
        expect(data.length).toBe(3);
        
    });

    it('expect service property: "strNomeTipoCooperacao" to have the right translations key', function () {

        var data = [];
        tipoCooperacaoService.load().then(function (result) {
            data = result;
        });
        $rootScope.$digest();
        expect(data[0].strNomeTipoCooperacao).toBe("TIPOCOOPERACAO.REGIONAL");
        expect(data[1].strNomeTipoCooperacao).toBe("TIPOCOOPERACAO.BILATERAL");
        expect(data[2].strNomeTipoCooperacao).toBe("TIPOCOOPERACAO.TRILATERAL");

    });

    it('expect service to return translated values based on current location', function () {

        var data = [];

        $translate.use('pt');
        tipoCooperacaoService.load().then(function (result) {
            data = result;
        });
        $rootScope.$digest();

        //test
        expect(data[0].strNomeTipoCooperacao).toBe("Regional");

        $translate.use('en'); 
        tipoCooperacaoService.load().then(function (result) {
            data = result;
        });
        $rootScope.$digest();

        //test
        expect(data[0].strNomeTipoCooperacao).toBe("Region");

    });

});