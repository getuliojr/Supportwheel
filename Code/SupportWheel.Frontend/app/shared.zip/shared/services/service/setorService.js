﻿(function () {

    'use strict';

    /**
     * @ngdoc service
     * @name shared.services.service.service:setor
     *
     * @requires shared.services.factory.service:appResource
     *
     * @description
     *
     * This service is responsable to make the interface of the application with the database for the table 'Setor'
     *
     */
    angular.module('shared.services.service.setor', [
        'shared.services.factory.appResource'
        ])
        .service('setorService', setorService);

    //Inject the dependencies
    setorService.$inject = ['appResourceFactory'];

    //Create the service
    function setorService(appResourceFactory) {

        var service = appResourceFactory("setor", "intIdSetor");

        return service;
    }
})()