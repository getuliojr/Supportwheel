﻿(function () {

    'use strict';

    //Define o módulo
    angular.module('shared.services.service.areaGeografica', [
        'shared.services.factory.appResource'
        ])
        .service('areaGeograficaService', areaGeograficaService);

    //Injeta dependencias
    areaGeograficaService.$inject = ['appResourceFactory'];

    //Cria o serviço
    function areaGeograficaService(appResourceFactory) {

        var service = appResourceFactory("areaGeografica", "intIdAreaGeografica");

        return service;
    }
})()