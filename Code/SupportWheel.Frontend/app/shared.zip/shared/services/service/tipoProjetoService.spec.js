﻿describe('Shared.Services.Service: tipoProjeto', function () {

    //Variable for itens that are going to be used in the tests
    var tipoProjetoService, $translate, $rootScope;

    //Load Services
    beforeEach(module('shared.services.service', 'ngStorage', 'ngMaterial', 'pascalprecht.translate'));

    //Fake translation values
    beforeEach(module(function ($translateProvider) {
        $translateProvider.translations('en', { 'TIPOPROJETO.PROGRAMA': 'Program' });
        $translateProvider.translations('pt', { 'TIPOPROJETO.PROGRAMA': 'Programa' });
    }));

    //Inject Dependencies
    beforeEach(inject(function (_tipoProjetoService_, _$translate_, _$rootScope_) {

        //Create new scope
        tipoProjetoService = _tipoProjetoService_;
        $translate = _$translate_;
        $rootScope = _$rootScope_;

        //Set to a non existent culture, so it does not interfere with tests
        $translate.use('xx');

    }));


    it('expect service to be defined', function () {
        expect(tipoProjetoService).toBeDefined();
        expect(tipoProjetoService.load).toBeDefined();
        
    });


    it('expect service to return 3 itens', function () {
        var data = [];
        tipoProjetoService.load()
            .then(function (result) {
                data = result;
            });
        $rootScope.$digest();
        expect(data.length).toBe(3);
        
    });

    it('expect service property: "strNomeTipoProjeto" to have the right translations key', function () {

        var data = [];
        tipoProjetoService.load().then(function (result) {
            data = result;
        });
        $rootScope.$digest();
        expect(data[0].strNomeTipoProjeto).toBe("TIPOPROJETO.PROGRAMA");
        expect(data[1].strNomeTipoProjeto).toBe("TIPOPROJETO.PROJETO");
        expect(data[2].strNomeTipoProjeto).toBe("TIPOPROJETO.ATIVIDADE");

    });

    it('expect service to return translated values based on current location', function () {

        var data = [];

        $translate.use('pt');
        tipoProjetoService.load().then(function (result) {
            data = result;
        });
        $rootScope.$digest();

        //test
        expect(data[0].strNomeTipoProjeto).toBe("Programa");

        $translate.use('en'); 
        tipoProjetoService.load().then(function (result) {
            data = result;
        });
        $rootScope.$digest();

        //test
        expect(data[0].strNomeTipoProjeto).toBe("Program");

    });

});