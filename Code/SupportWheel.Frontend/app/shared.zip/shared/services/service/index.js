﻿(function () {

    'use strict';

    angular.module('shared.services.service', [
        'shared.services.service.areaGeografica',        
        'shared.services.service.culture',
        'shared.services.service.hub',
        'shared.services.service.instituicao',
        'shared.services.service.notification',
        'shared.services.service.pais',
        'shared.services.service.organismo',
        'shared.services.service.paisCultura',
        'shared.services.service.projetoParceiro',
        'shared.services.service.projetoParceiroInstituicao',
        'shared.services.service.projetoSubsetor',
        'shared.services.service.retryQueue',
        'shared.services.service.security',
        'shared.services.service.setor',
        'shared.services.service.subsetor',
        'shared.services.service.tipoCooperacao',
        'shared.services.service.tipoProjeto',
        'shared.services.service.usuario',
        'shared.services.service.viewstate'
    ]);

})();