﻿(function() {

    'use strict';

    angular
        .module('shared.services.service.paisCultura', [
            'shared.services.factory.appResource'
        ])
        .service('paisCulturaService', paisCulturaService);

    paisCulturaService.$inject = ['appResourceFactory'];

    function paisCulturaService(appResourceFactory) {

        var service = appResourceFactory('paisCultura', '');
               
        return service;
    }
})();