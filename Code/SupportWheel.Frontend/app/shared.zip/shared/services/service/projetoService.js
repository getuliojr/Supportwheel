﻿(function () {

    'use strict';

    /**
     * @ngdoc service
     * @name shared.services.service.service:projeto
     *
     * @requires shared.services.factory.service:appResource
     *
     * @description
     *
     * This service is responsable to make the interface of the application with the database for the table 'Projeto'
     *
     */
    angular.module('shared.services.service.projeto', [
        'shared.services.factory.appResource'
        ])
        .service('projetoService', projetoService);

    //Inject the dependencies
    projetoService.$inject = ['appResourceFactory'];

    //Create the service
    function projetoService(appResourceFactory) {

        var service = appResourceFactory("projeto", "intIdProjeto");
        service.createHub();

        service.validate = function (dados) {
            var erros = [];

            if (!dados.strIdCultura)
                erros.push('É necessário informar em qual idioma estão as informações destes projeto.');

            if (!dados.intIdTipoProjeto)
                erros.push('É necessário informar o tipo de projeto.');

            if (!dados.intIdTipoCooperacao)
                erros.push('É necessário informar o tipo de cooperação.');

            if (!dados.strTituloProjeto)
                erros.push('É necessário informar o título do projeto.');

            if (!dados.strObjetivo)
                erros.push('É necessário informar o objetivo do projeto.');

            if (!dados.strResultado)
                erros.push('É necessário informar o resultado do projeto.');

            if (!dados.dteInicio)
                erros.push('É necessário informar a data de início do projeto.');

            if (!dados.dteTermino)
                erros.push('É necessário informar a data de término do projeto.');

            if (!dados.projetoParceiros || dados.projetoParceiros.length == 0)
                erros.push('O projeto deve possuir ao menos um parceiro vinculado.');

            if (!dados.projetoSubsetores || dados.projetoSubsetores.length == 0)
                erros.push('O projeto deve possuir ao menos um subsetor vinculado.');

            return erros;
        };

        return service;
    }
})()
