﻿(function () {

    'use strict';

    /**
     * @ngdoc service
     * @name shared.services.service.service:projetoSubsetor
     *
     * @requires shared.services.factory.service:appResource
     *
     * @description
     *
     * This service is responsable to make the interface of the application with the database for the table 'ProjetoSubsetor'
     *
     */
    angular.module('shared.services.service.projetoSubsetor', [
        'shared.services.factory.appResource'
        ])
        .service('projetoSubsetorService', projetoSubsetorService);

    //Inject the dependencies
    projetoSubsetorService.$inject = ['appResourceFactory'];

    //Create the service
    function projetoSubsetorService(appResourceFactory) {

        var service = appResourceFactory("projetoSubsetor", "intIdProjetoSubsetor");

        service.validar = function (dados) {
            var erros = [];

            if (!dados.intIdSubsetor)
                erros.push('É necessário informar qual subsetor se está tentando vincular ao projeto.');

            return erros;
        };

        return service;
    }
})()