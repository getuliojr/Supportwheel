﻿(function () {

    'use strict';

    /**
     * @ngdoc service
     * @name shared.services.service.service:projetoParceiroInstituicao
     *
     * @requires shared.services.factory.service:appResource
     *
     * @description
     *
     * This service is responsable to make the interface of the application with the database for the table 'ProjetoParceiroInstituicao'
     *
     */
    angular.module('shared.services.service.projetoParceiroInstituicao', [
        'shared.services.factory.appResource'
        ])
        .service('projetoParceiroInstituicaoService', projetoParceiroInstituicaoService);

    //Inject the dependencies
    projetoParceiroInstituicaoService.$inject = ['appResourceFactory'];

    //Create the service
    function projetoParceiroInstituicaoService(appResourceFactory) {

        var service = appResourceFactory("projetoParceiroInstituicao", "intIdProjetoParceiroInstituicao");

        service.validar = function (dados) {
            var erros = [];

            if (!dados.strNomeInstituicao)
                erros.push('É necessário informar o nome da instituição.');

            return erros;
        };

        return service;
    }
})()