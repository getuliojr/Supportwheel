﻿(function () {

    'use strict';

    /**
     * @ngdoc service
     * @name shared.services.service.service:projetoParceiro
     *
     * @requires shared.services.factory.service:appResource
     *
     * @description
     *
     * This service is responsable to make the interface of the application with the database for the table 'ProjetoParceiro'
     *
     */
    angular.module('shared.services.service.projetoParceiro', [
        'shared.services.factory.appResource'
        ])
        .service('projetoParceiroService', projetoParceiroService);

    //Inject the dependencies
    projetoParceiroService.$inject = ['appResourceFactory'];

    //Create the service
    function projetoParceiroService(appResourceFactory) {

        var service = appResourceFactory("projetoParceiro", "intIdProjetoParceiro");

        service.validar = function (dados) {
            var erros = [];

            if (!dados.intIdOrganismoInternacional && !dados.intIdPais)
                erros.push('É necessário informar qual organismo internacional ou país se está tentando vincular ao projeto.');

            return erros;
        };

        return service;
    }
})()