﻿(function () {

    'use strict';

    /**
     * @ngdoc service
     * @name shared.services.service.service:subsetor
     *
     * @requires shared.services.factory.service:appResource
     *
     * @description
     *
     * This service is responsable to make the interface of the application with the database for the table 'Subsetor'
     *
     */
    angular.module('shared.services.service.subsetor', [
        'shared.services.factory.appResource'
        ])
        .service('subsetorService', subsetorService);

    //Inject dependencies
    subsetorService.$inject = ['appResourceFactory'];

    //Create the service
    function subsetorService(appResourceFactory) {

        var service = appResourceFactory("subsetor", "intIdSubsetor");

        return service;
    }
})()