﻿(function () {

    'use strict';

    //Define o módulo
    angular
        .module('shared', [
            'shared.directives',
            'shared.filters',
            'shared.services'
        ]);
})();