﻿
(function () {

    'use strict';

     /**
     * @ngdoc overview
     * @name components.subsetor.subsetorSelect
     * @description
     *
     * # subsetorSelect - Component #
     *
     * This component is responsible to render a select list with autocomplete will all values of the item 'Subsetor', it is
     * also responsible to change the values based on the current culture or if the Id of the 'Setor' changes
     *
     * @example
       <pre>
        <abc-subsetor-select 
            cache="cache" 
            id-setor="idSetor" 
            subsetor="subsetor" 
            required="required">
        </abc-subsetor-select>'
       </pre>
     */
    angular
        .module('components.subsetor.subsetorSelect', [
            'shared.services.service.subsetor',
            'shared.services.service.culture',
            'shared.services.factory.handleException'
        ])

        .directive('abcSubsetorSelect', subsetorSelectDirective)
        .controller('SubsetorSelectController', SubsetorSelectController);


    /**
     * @ngdoc directive
     * @name components.subsetor.subsetorSelect.directive:subsetorSelect
     *
     * @restrict 'E'
     *
     * @param {int} id-setor The Id of the item that should filter the 'Subsetor'. 
     * @param {object=} subsetor An object containing at least a property of 'intIdSubsetor' that should be selected. On selection this will have the item selected by the user
     * @param {boolean=} required Sets if the controller is required or not when submitting a form
     * @param {boolean=} cache Sets if the controller should cache the data. Defaults to true if not set. It need to be set to false to not cache
     *
     * @description
     *
     * This component will render a select list with all values of 'Subsetor' and control the current culture set.
     * The selected item will be available throught the parameterer 'id'
     * When 'idSetor' changes, the controller gets its results again.
     *
     */
    function subsetorSelectDirective() {
        return {
            restrict: 'E',
            controller: 'SubsetorSelectController',
            templateUrl: 'app/components/subsetor/subsetorSelect/subsetorSelect.html',
            controllerAs: 'subsetorSelect',
            scope: {},
            bindToController: {
                idSetor: '=',
                subsetor: '=',
                required: '=',
                cache: '='
            }
        }
    }

    //Inject Dependencies
    SubsetorSelectController.$inject = ['subsetorService', 'cultureService', '$scope', 'handleExceptionFactory'];

    /**
     * @ngdoc controller
     * @name components.subsetor.subsetorSelect.controller:SubsetorSelectController
     *
     * @requires shared.services.service.service:subsetor
     * @requires shared.services.service.service:culture
     * @requires shared.services.factory.service:handleException
     *
     * @description
     *
     * It has the logic behind the component
     *
     */
    function SubsetorSelectController(subsetorService, cultureService, $scope, handleExceptionFactory) {

        var vm = this;
        vm.subsetores = [];

        //API
        vm.selectedItemChange = selectedItemChange;

        //Init the controller
        init();

        /**
        * @ngdoc function
        * @name init
        * @methodOf components.subsetor.subsetorSelect.controller:SubsetorSelectController
        *
        * @description
        *
        * This is a private function that is called when the controller is initialized and everytime an item or culture is changed
        */
        function init() {
            //Only load 'subsetores' if one item in 'setor' is selected
            if (!!vm.idSetor) {
                var queryParams = { intIdSetor: vm.idSetor, strIdCultura: cultureService.getCulture().culture };

                //Defaults to true if not set
                if (vm.cache !== false) {
                    queryParams.cache = true;
                }

                //Loads the 'subsetor' list based on the 'setor' and culture
                subsetorService
                    .load(queryParams)
                    .then(function (data) {

                        //Make the data available to the controller
                        vm.subsetores = data;

                        //Sets the selected item right based on the culture loaded
                        if (!!vm.subsetor && !!vm.subsetor.intIdSubsetor) {
                            var index = _.findIndex(vm.subsetores, { intIdSubsetor: vm.subsetor.intIdSubsetor });
                            if (index > -1) {
                                //Be sure 'subsetor' has completed information
                                angular.extend(vm.subsetor, vm.subsetores[index]);
                                
                                //Selects item in the list
                                vm.selectedItem = vm.subsetores[index];
                            }
                        }
                    })
                    //handle exceptions
                    .catch(handleExceptionFactory);
            } 
        }

        //Listen for culture Changes to update the value in the correct language
        var cultureEvent = cultureService.onCultureChange(init);
        $scope.$on('$destroy', cultureEvent);

        //Watch for changes in the id or required parameters that has been passed
        $scope.$watch(function () {
            var intIdSubsetor = undefined;
            if (!!vm.subsetor && !!vm.subsetor.intIdSubsetor) {
                intIdSubsetor = vm.subsetor.intIdSubsetor;
            }
            return { idSetor: vm.idSetor, intIdSubsetor: intIdSubsetor, required: vm.required };
        }, function (newValue, oldValue) {
            // Check if value has changes
            if (newValue === oldValue) {
                return;
            }

            //If setor has changed or subsetor has been cleared
            if ((newValue.idSetor !== oldValue.idSetor && oldValue.idSetor != undefined) || (newValue.intIdSubsetor == undefined && oldValue.intIdSubsetor != undefined)) {
                vm.subsetor = undefined;
                vm.searchText = undefined;
            }

            //When values changes, init the controller again
            init();
        }, true);


        /**
        * @ngdoc function
        * @name selectedItemChange
        * @methodOf components.subsetor.subsetorSelect.controller:SubsetorSelectController
        *
        * @description
        *
        * Everytime a user changes the selected value this item check if the value is different from the one initial set and if are, update the parameter 'subsetor'.
        * It also sets required message based if the component is required or not
        */
        function selectedItemChange(item, ctrl) {
            if (!!item) {
                //Item changed
                if (vm.subsetor == undefined || vm.subsetor.intIdSubsetor != item.intIdSubsetor) {
                    vm.subsetor = item;
                }
                //Set requiredError to not show
                if (!!vm.required) {
                    ctrl.$setValidity("required", true);
                }
            } else {
                //clear value
                vm.subsetor = undefined;

                //set required error to show
                if (!!vm.required) {
                    ctrl.$setValidity("required", false);
                }
            }
        }

    }
})();