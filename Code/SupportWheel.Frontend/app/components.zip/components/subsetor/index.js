﻿(function () {
    'use strict';

    angular
        .module('components.subsetor', [
            'components.subsetor.subsetorSelect'

    ]);

})();

