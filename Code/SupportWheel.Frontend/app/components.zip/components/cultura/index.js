﻿(function () {
    'use strict';

    angular
        .module('components.cultura', [
            'components.cultura.culturaSelect'

    ]);

})();

