﻿(function () {

    'use strict';

    /**
    * @ngdoc overview
    * @name components.instituicao.instituicao.form
    * 
    * @description
    *
    * # abcInstituicaoForm - Component #
    *
    */
    angular
        .module('components.instituicao.instituicao.form', [
            'shared.services.factory.handleException',
            'shared.services.service.culture',
            'shared.services.service.instituicao',
            'shared.services.service.viewstate',
            'shared.services.service.notification'
        ])


     /**
     * @ngdoc directive
     * @name components.instituicao.instituicao.form.directive:abcInstituicaoForm
     * 
     * @restrict 'E'
     * 
     * @param {int=} id Id of an institution to be loaded
     * 
     * @description
     *
     * # abcInstituicaoForm - Component #
     *
     * This component is responsible to render a form with all values of an institution, so it can be updated or deleted.
     *
     */
    .component('abcInstituicaoForm', {
        templateUrl: 'app/components/instituicao/instituicao.form/instituicao.form.html',
        controller: InstituicaoFormController,
        bindings: {
            id:"<?"
        }
    });


    //Inject Dependencies
    InstituicaoFormController.$inject = ['handleExceptionFactory', 'viewstateService', 'notificationService', 
        'cultureService', 'instituicaoService', '$location'];


    /**
     * @ngdoc controller
     * @name components.instituicao.instituicao.form.controller:InstituicaoFormController
     *
     * @requires shared.services.service.service:instituicao
     * @requires shared.services.factory.service:handleException
     *
     * @description
     *
     * It has the logic behind the component
     *
     */
    function InstituicaoFormController(handleExceptionFactory, viewstateService, notificationService, 
        cultureService, instituicaoService, $location) {

        var vm = this;

        //To avoid the data to be destroyed in case of a tab change
        vm.data = viewstateService.getView('Instituicao');
      

        //Init component
        vm.$onInit = init;

        //PUBLIC API
        vm.saveInstituicao = saveInstituicao;
        vm.removeInstituicao = removeInstituicao;
        vm.newInstituicao = newInstituicao;

        /**
        * @ngdoc function
        * @name init
        * @methodOf  components.instituicao.instituicao.form.controller:InstituicaoFormController
        * @private
        *
        * @description
        *
        * This is a private function that is called when the controller is initialized
        */
        function init() {

            //Load the data of the project
            if (vm.id != undefined) {
                instituicaoService
                    .load({ intIdInstituicao: vm.id })
                    .then(function (data) {
                        if (data.intIdInstituicao == undefined) {
                            notificationService.show('error', "GENERAL.ERROR-NOTFOUND");
                            //Apaga dados que poderiam existir na view em memória
                            viewstateService.newView('Instituicao');
                            $location.path("restrita/instituicao");
                        } else {
                            data.pais = { intIdPais: data.intIdPais }
                            vm.data = data;
                        }

                    })
                    .catch(handleExceptionFactory);
            }

        };



        /**
        * @ngdoc function
        * @name saveInstituicao
        * @methodOf  components.instituicao.instituicao.form.controller:InstituicaoFormController
        * @param {object} instituicao Expect an object of the data of the institution that should be saved
        *
        * @description
        *
        * This is responsable to save the institution to the database.
        */
        function saveInstituicao(instituicao) {
            var successCB = function (result) {
                notificationService.show('success', "GENERAL.SAVED-SUCCESSFULLY");
                
                //redirect to edit page
                $location.path("restrita/instituicao/" + result.intIdInstituicao);
            }

            var params = angular.copy(instituicao);

            //parse values of pais
            if (!!params.pais && !!params.pais.intIdPais) {
                params.intIdPais = params.pais.intIdPais;
                params.strNomePais = params.pais.strNomePais;
                delete params.pais;
            }
            instituicaoService.save(params).then(successCB, handleExceptionFactory);
          
        }

       /**
       * @ngdoc function
       * @name removeInstituicao
       * @methodOf  components.instituicao.instituicao.form.controller:InstituicaoFormController
       * @param {int} intIdInstituicao Expect an id of the institution to be deleted
       *
       * @description
       *
       * This is responsable to remove the project to the database.
       */
        function removeInstituicao(intIdInstituicao) {
            var successCB = function (result) {
                notificationService.show('success', "GENERAL.REMOVED-SUCCESSFULLY");
                //Apaga dados que poderiam existir na view em memória
                viewstateService.newView('Instituicao');
                $location.path("restrita/instituicao");
            }

            instituicaoService.remove({ intIdInstituicao: intIdInstituicao })
                .then(successCB, handleExceptionFactory);
        }

      /**
      * @ngdoc function
      * @name newInstituicao
      * @methodOf  components.instituicao.instituicao.form.controller:InstituicaoFormController
      *
      * @description
      *
      * This is responsable to redirect the user to a new form
      */
        function newInstituicao() {
            viewstateService.newView('Instituicao');
            $location.path("restrita/instituicao");
        }
    }
})();
