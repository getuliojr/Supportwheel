﻿(function () {

    'use strict';

    /**
    * @ngdoc overview
    * @name components.instituicao.instituicaoSelect
     * 
    * @description
    *
    * # abcInstituicaoSelect - Component #
    * 
    * This component is responsible to render a select list with autocomplete that will apply on all items
    * of type 'Institution'. 
    *
    */
    angular
        .module('components.instituicao.instituicaoSelect', [
            'shared.services.service.instituicao',
            'shared.services.factory.handleException'
        ])

        /**
        * @ngdoc directive
        * @name components.instituicao.instituicaoSelect.directive:abcInstituicaoSelect
        * 
        * @restrict 'E'
        * 
        * @param {object=} instituicao An object containing at least a property of 'intIdInstituicao' that should be selected. When the user selects an item it will output in this property.
        * @param {boolean=} required Sets if the controller is required or not when submitting a form.
        * @param {boolean=} cache Sets if the controller should cache the data. Defaults to true if not set. It need to be set to false to not cache
        * @param {boolean=} disabled Sets if the controller should be disabled or not.
        * 
        * @description
        *
        * # abcInstituicaoSelect - Component #
        *
        * This component is responsible to render a select list with autocomplete that will apply on all items
        * of type 'Institution'. 
        *
        */
        .component('abcInstituicaoSelect', {
            templateUrl: 'app/components/instituicao/instituicaoSelect/instituicaoSelect.html',
            controller: InstituicaoSelectController,
            bindings: {
                instituicao: '=?',
                required: '<',
                cache: '<',
                disabled: '<'
            }
        });




    //Inject Dependencies
    InstituicaoSelectController.$inject = ['instituicaoService', '$scope', 'handleExceptionFactory'];

    /**
     * @ngdoc controller
     * @name components.instituicao.instituicaoSelect.controller:InstituicaoSelectController
     *
     * @requires shared.services.service.service:instituicao
     * @requires shared.services.factory.service:handleException
     *
     * @description
     *
     * It has the logic behind the component
     *
     */
    function InstituicaoSelectController(instituicaoService, $scope, handleExceptionFactory) {

        var vm = this;

        //Default value for cache
        if (vm.cache === undefined) { vm.cache = true};
        vm.instituicoes = [];

        //Public API
        vm.selectedItemChange = selectedItemChange;

        

        //Init the controller
        init();

        /**
        * @ngdoc function
        * @name init
        * @methodOf components.instituicao.instituicaoSelect.controller:InstituicaoSelectController
        *
        * @description
        *
        * This is a private function that is called when the controller is initialized and everytime an item 
        * or culture is changed
        * 
        */
        function init() {

            var queryParams = { cache: vm.cache };

            //Loads the instituicao list based on the geographic area and culture
            instituicaoService.load(queryParams)
                .then(success)
                .catch(handleExceptionFactory);
           

            function success(data) {

                //Make the data available to the controller
                vm.instituicoes = data;
            }
        }


        /**
        * @ngdoc function
        * @name selectedItemChange
        * @methodOf components.instituicao.instituicaoSelect.controller:InstituicaoSelectController
        *
        * @param {object=} item An object with the item, 'Instituicao', that has changed
        * @param {reference=} ctrl A reference to the controller, so it can set if it is required or not.
        * 
        * @description
        *
        * Everytime a user changes the selected value this item check if the value is different from the one
        * initial set and if are, update the parameter 'pais'.
        * It also sets required message based if the component is required or not
        */
        function selectedItemChange(item, ctrl) {
            if (!!item) {
                //Item changed
                if (vm.instituicao === undefined || vm.instituicao.intIdInstituicao !== item.intIdInstituicao) {
                    vm.instituicao = item;
                }
                //Set requiredError to not show
                if (!!vm.required) {
                    ctrl.$setValidity("required", true);
                }
            } else {
                //clear value
                vm.instituicao = undefined;

                //set required error to show
                if (!!vm.required) {
                    ctrl.$setValidity("required", false);
                }
            }
        }

    }
})();





