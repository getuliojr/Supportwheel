﻿(function () {

    'use strict';

    /**
    * @ngdoc overview
    * @name components.instituicao.instituicao.search
    * 
    * @description
    *
    * # abcInstituicaoSearch - Component #
    *
    */
    angular
        .module('components.instituicao.instituicao.search', [
            'shared.services.factory.handleException',
            'shared.services.service.culture',
            'shared.services.service.instituicao',
            'shared.services.service.viewstate',
            'shared.services.service.notification'
        ])


     /**
     * @ngdoc directive
     * @name components.instituicao.instituicao.search.directive:abcInstituicaoSearch
     * 
     * @restrict 'E'
     * 
     * 
     * @description
     *
     * # abcInstituicaoSearch - Component #
     *
     * This component is responsible to render a form to filter institutions
     *
     */
    .component('abcInstituicaoSearch', {
        templateUrl: 'app/components/instituicao/instituicao.search/instituicao.search.html',
        controller: InstituicaoSearchController,
        bindings: {

        }
    });


    //Inject Dependencies
    InstituicaoSearchController.$inject = ['handleExceptionFactory', 'viewstateService', 'notificationService', 
        'cultureService', 'instituicaoService', '$scope', '$location'];


    /**
     * @ngdoc controller
     * @name components.instituicao.instituicao.search.controller:InstuticaoSearchController
     *
     * @requires shared.services.service.service:instituicao
     * @requires shared.services.factory.service:handleException
     *
     * @description
     *
     * It has the logic behind the component
     *
     */
    function InstituicaoSearchController(handleExceptionFactory, viewstateService, notificationService,
        cultureService, instituicaoService, $scope, $location) {

        var vm = this;
        //To avoid the data to be destroyed in case of a tab change
        vm.data = viewstateService.getView('SearchInstituicao');
        vm.data.instituicoes = vm.data.instituicoes || [];

        
        //Init component
        vm.$onInit = init;
        vm.selectInstituicao = selectInstituicao
        vm.searchInstituicao = searchInstituicao
        vm.onPaginate = onPaginate


        /**
        * @ngdoc function
        * @name init
        * @methodOf  components.instituicao.instituicao.search.controller:InstituicaoSearchController
        * @private
        *
        * @description
        *
        * This is a private function that is called when the controller is initialized
        */
        function init() {

            //Configure dataList Component
            vm.config = {
                enableFilter: true,
                enableRowSelection: false,
                columns: [{ field: 'strNomePais', isNumeric: false, displayName: '{{"INSTITUICAO-SEARCH.COUNTRY" | translate }}' },
                        { field: 'strNomeInstituicao', isNumeric: false, displayName: '{{"INSTITUICAO-SEARCH.NAME" | translate }}' }],
                itemMenu: [{
                    name: '{{"GENERAL.SELECT" | translate }}', icon: 'edit', ariaLabel: '{{"GENERAL.SELECT" | translate }}',
                    onClick: vm.selectInstituicao
                }]
            };

            //Configure pagination start values
            vm.data.intPageSize = 15;
            vm.data.intPageNumber = 1;

            //Listen for culture Changes to update the value in the correct language
            var cultureEvent = cultureService.onCultureChange(updateResult);

            //Listen for changes on instituição
            var instituicaoEvent = instituicaoService.listenEvent.both.all(updateResult);

            //Cleanup events when controller is destroyed
            $scope.$on("$destroy", instituicaoEvent);
            $scope.$on('$destroy', cultureEvent);

            //Responsable to change the data entered and selected by the user already to a new culture set.
            function updateResult() {
                //Se já fez uma pesquisa
                if (!!vm.data.searched) {
                    //Refaz para trazer no novo idioma
                    var data = angular.copy(vm.data);
                    data.cache = false;
                    data.applyScope = true;
                    searchInstituicao(data);
                }
                
            }
        };


        function onPaginate() {
            searchInstituicao(vm.data);
        }

        function selectInstituicao(item) {
            var item = item.item;
            $location.path("/restrita/instituicao/" + item.intIdInstituicao);
        }

        function searchInstituicao(params) {
            var query = angular.copy(params);
            delete query.instituicoes;
            
            //cache query if not set by the user
            if (query.cache == undefined) {
                query.cache = true;
            }

            //Pega o cultura atual
            var currentCulture = cultureService.getCulture();
            if (currentCulture != undefined) {
                query.strIdCultura = currentCulture.culture;
            } else {
                //Default
                query.strIdCultura = "pt-BR";
            }

            //Verifica se selecionou um pais para mapear
            if (!!query.pais && !!query.pais.intIdPais) {
                query.intIdPais = query.pais.intIdPais;
            }

            //Get projects based on the criteria selected
            instituicaoService
                .load(query)
                .then(function (data) {
                    vm.data.instituicoes = data;
                    vm.data.searched = true;
                    vm.data.intTotalRecords = 0;
                    if (data != undefined && data.length > 0 && data[0].intTotalRecords > 0) {
                        vm.data.intTotalRecords = data[0].intTotalRecords;
                    }
                })
                .catch(handleExceptionFactory);
        }
    }
})();
