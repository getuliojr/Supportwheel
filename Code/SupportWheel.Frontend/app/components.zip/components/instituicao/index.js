﻿(function () {
    'use strict';

    /**
     * @ngdoc overview
     * @name components.instituicao
     * @description
     *
     * # Instituicao - Component #
     *
     * This components hold the functionalities to compose the screen to maintain registers of instituitions.
     * 
     * Below is a list of the components. Click on each one for more information:
     *    
     * - {@link componentes.instituicao.instituicao.form instituicaoForm}
     * - {@link componentes.instituicao.instituicao.search instituicaoSearch}
     * - {@link componentes.instituicao.instituicaoSelect instituicaoSelect}
     *     
     */
    angular
        .module('components.instituicao', [
            'components.instituicao.instituicao.form',
            'components.instituicao.instituicaoSelect',
            'components.instituicao.instituicao.search'
    ]);

})();

