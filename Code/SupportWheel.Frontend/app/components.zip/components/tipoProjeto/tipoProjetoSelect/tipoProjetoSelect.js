﻿(function () {

    'use strict';

     /**
     * @ngdoc overview
     * @name components.tipoProjeto.tipoProjetoSelect
     * @description
     *
     * # tipoProjectSelect - Component #
     *
     * This component is responsible to render a select list with autocomplete will all values of the item 'tipoProjeto', it is
     * also responsible to change the values based on the current culture
     *
     * @example
       <pre>
        <abc-tipo-projeto-select id="id" required="required"></abc-tipo-projeto-select>
       </pre>
     */
    angular
        .module('components.tipoProjeto.tipoProjetoSelect', [
            'shared.services.service.tipoProjeto',
            'shared.services.service.culture'
        ])

        .directive('abcTipoProjetoSelect', tipoProjetoSelectDirective)
        .controller('TipoProjetoSelectController', TipoProjetoSelectController);


    /**
     * @ngdoc directive
     * @name components.tipoProjeto.tipoProjetoSelect.directive:tipoProjetoSelect
     * @restrict 'E'
     * @param {int=} id The Id of the item that is selected or should be selected. It automatically maps to intIdTipoProjeto
     * @param {boolean=} required Sets if the controller is required or not when submitting a form
     *
     * @description
     *
     * This component will render a select list with all values of 'tipoProjeto' and control the current culture set.
     * The selected item will be available throught the parameterer 'id'
     *
     */
    function tipoProjetoSelectDirective() {
        return {
            restrict: 'E',
            controller: 'TipoProjetoSelectController',
            templateUrl: 'app/components/tipoProjeto/tipoProjetoSelect/tipoProjetoSelect.html',
            controllerAs: 'tipoProjetoSelect',
            scope: {},
            bindToController: {
                id: '=',
                required: '='
            }
        }
    }

    //Inject Dependencies
    TipoProjetoSelectController.$inject = ['tipoProjetoService', 'cultureService', '$scope'];

    /**
     * @ngdoc controller
     * @name components.tipoProjeto.tipoProjetoSelect.controller:TipoProjetoSelectController
     * @description
     *
     * It has the logic behind the component
     *
     */
    function TipoProjetoSelectController(tipoProjetoService, cultureService, $scope) {

        var vm = this;
        vm.tiposProjeto = [];

        vm.selectedItemChange = selectedItemChange;

        init();

        /**
        * @ngdoc function
        * @name init
        * @methodOf components.tipoProjeto.tipoProjetoSelect.controller:TipoProjetoSelectController
        *
        * @description
        *
        * This is a private function that is called when the controller is initialized and everytime an item or culture is changed
        */
        function init() {
            tipoProjetoService.load().then(function (data) {
                vm.tiposProjeto = data;

                if (!!vm.id) {
                    var index = _.findIndex(vm.tiposProjeto, { intIdTipoProjeto: vm.id });
                    if (index > -1) {
                        vm.selectedItem = vm.tiposProjeto[index];
                    }
                }
            });
        }

        //Listen for culture Changes to update the value in the correct language
        var cultureEvent = cultureService.onCultureChange(init);
        $scope.$on('$destroy', cultureEvent);

        //Watch for changes in the id or required parameters that has been passed
        $scope.$watch(function () {
            return { id: vm.id, required: vm.required };
        }, function (newValue, oldValue) {
            // Check if value has changes
            if (newValue === oldValue) {
                return;
            }
            //When values changes, init the controller again
            init();
        }, true);


        /**
        * @ngdoc function
        * @name selectedItemChange
        * @methodOf components.tipoProjeto.tipoProjetoSelect.controller:TipoProjetoSelectController
        *
        * @description
        *
        * Everytime a user changes the selected value this item check if the value is different from the one initial set and if are, update the parameter 'id'.
        * It also sets error messages based if the component is required or not
        */
        function selectedItemChange(item, ctrl) {
            if (!!item) {
                //Item changed
                if (item.intIdTipoProjeto != vm.id) {
                    vm.id = item.intIdTipoProjeto;
                }
                //Set requiredError to not show
                if (!!vm.required) {
                    ctrl.$setValidity("required", true);
                }
            } else {
                //clear value
                vm.id = undefined;
                //set required error to show
                if (!!vm.required) {
                    ctrl.$setValidity("required", false);
                }
            }
        }

    }
})();