﻿describe('Component.tipoProjeto: tipoProjetoSelect', function () {

    //Variable for itens that are going to be used in the tests
    var $compile, directive, controllerAs, directiveName, isolateScope;

    //Load Module to be Tested
    beforeEach(module('components.tipoProjeto.tipoProjetoSelect', 'templates'));

    //Load Services
    beforeEach(module('shared.services.service', 'ngStorage', 'ngMaterial', 'pascalprecht.translate'));

    //Inject Dependencies
    beforeEach(inject(function (_$rootScope_, _$controller_, _$compile_) {

        //Create new scope
        scope = _$rootScope_.$new();
        //Configure to always start as an empty config
        scope.config = {}; 

        //Inject dependencies
        $compile = _$compile_;

        //Create Directive
        var directiveElement = '<abc-tipo-projeto-select id="id" required="required"></abc-tipo-projeto-select>';
        directive = getCompiledElement(directiveElement);
        
        //Other variables
        controllerAs = 'tipoProjetoSelect';
        directiveName = 'abcTipoProjetoSelect';
        isolateScope = directive.isolateScope();
        

    }));


    it('expect template to be replaced', function () {
        expect(directive.find('md-autocomplete').length).toBe(1);
    });

    it('expect controller to be defined', function () {
        var controller = directive.controller(directiveName);
        expect(controller).toBeDefined();
    });

    it('expect controller to be initialized', function () {
        var controller = directive.controller(directiveName);
        expect(controller.tiposProjeto.length).toBe(3);
    });

    it('expect controllerAs name to be right', function () {
        expect(isolateScope.hasOwnProperty(controllerAs)).toBeTruthy();
    });

    it('expect parameter: "id" to be set', function () {
        var id = 2;
        scope.id = id;
        var controller = isolateScope[controllerAs];

        //Shouldn´t have a value yet
        expect(controller.id).toBeUndefined();

        //Run digest, setting new values in outer scope
        scope.$digest();

        expect(controller.id).toBe(id);

    });

    it('expect parameter: "required" to be set', function () {
        var required = false;
        scope.required = required;
        var controller = isolateScope[controllerAs];

        //Shouldn´t have a value yet
        expect(controller.required).toBeUndefined();

        //Run digest, setting new values in outer scope
        scope.$digest();

        expect(controller.required).toBe(required);

    });

    it('expect parameter: "id" to configure selected value in the list', function () {
        var controller = isolateScope[controllerAs];
        scope.id = 2;
        scope.$digest();
        expect(controller.searchText).toBe('TIPOPROJETO.PROJETO');

        scope.id = 3;
        scope.$digest();
        expect(controller.searchText).toBe('TIPOPROJETO.ATIVIDADE');

    });

    //Helper Function
    function getCompiledElement(el){
        var element = angular.element("<body>" + el + "</body");
        var compiledElement = $compile(element)(scope);     
        scope.$digest();       
        return compiledElement;
    }

});