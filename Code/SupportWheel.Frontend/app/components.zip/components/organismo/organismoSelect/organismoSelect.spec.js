﻿describe('Component.organismo: organismoSelect', function () {

    //Variable for itens that are going to be used in the tests
    var scope, controller, componentName, componentElement, $componentController, $compile, $httpBackend, mockHandleExceptionFactory, handleExceptionFactory, cultureService;

    //Load Module to be Tested
    //Allows to check if the module handleExceptionFactory has been called
    beforeEach(module('components.organismo.organismoSelect', 'templates', function ($provide) {
        $provide.decorator('handleExceptionFactory', function ($delegate) {
            mockHandleExceptionFactory = jasmine.createSpy('handleExceptionFactory', $delegate).and.callThrough();
            return mockHandleExceptionFactory;
        });
    }));

    //Load Services
    beforeEach(module('shared.services.service', 'ngStorage', 'ngMaterial', 'pascalprecht.translate'));

    //Load factories (resource, backend)
    beforeEach(module('shared.services.factory', 'ngResource', 'SignalR'));

   

    //Inject Dependencies
    beforeEach(inject(function (_$rootScope_, _cultureService_, _$compile_,_$httpBackend_, _handleExceptionFactory_, _$componentController_) {

        var mockDataPT = [{"intIdOrganismoInternacional": 1, "strIdCultura": "pt-BR", "strSiglaOrganismoInternacional": "PNUD", "strNomeOrganismoInternacional": "Programa das Nações Unidas" }];

        var mockDataEN = [{ "intIdOrganismoInternacional": 1, "strIdCultura": "en-US", "strSiglaOrganismoInternacional": "UNDP", "strNomeOrganismoInternacional": "United Nations Developing Program" }];
        
        //Create new scope
        scope = _$rootScope_.$new();

        //Configure to always disable cache, required for testing
        scope.cache = false;
        componentName = 'abcOrganismoSelect';

        //Inject dependencies
        $httpBackend = _$httpBackend_;
        $compile = _$compile_;
        cultureService = _cultureService_;
        handleExceptionFactory = _handleExceptionFactory_;
        $componentController = _$componentController_;


        //Mock htppGet
        $httpBackend.whenGET('/asamap/api/organismointernacional?cache=false&strIdCultura=pt-BR').respond(mockDataPT);
        $httpBackend.whenGET('/asamap/api/organismointernacional?cache=true&strIdCultura=pt-BR').respond(mockDataPT);
        $httpBackend.whenGET('/asamap/api/organismointernacional?cache=false&strIdCultura=en-US').respond(mockDataEN);
        $httpBackend.whenGET('/asamap/api/organismointernacional?cache=false&strIdCultura=es-ES').respond(500);

        //Set current culture to pt
        cultureService.setCulture('pt-BR');

        //Create Directive, cache should always be false to test it
        componentElement = '<abc-organismo-select cache="cache" organismo="organismo" disabled="disabled" required="required"></abc-organismo-select>';
        componentElement = getCompiledElement(componentElement);


    }));

    afterEach(function () {
        $httpBackend.verifyNoOutstandingExpectation();
        $httpBackend.verifyNoOutstandingRequest();
    });

    it('expect template to be replaced', function () {
        expect(componentElement.find('md-autocomplete').length).toBe(1);
    });

    it('expect controller to be defined', function () {
        controller = $componentController(componentName, { $scope: scope }, { cache: false });
        $httpBackend.flush();
        scope.$digest();
        expect(controller).toBeDefined();
    });

    it('expect controller to be attached to the scope as $ctrl', function () {
        controller = $componentController(componentName, { $scope: scope });
        $httpBackend.flush();
        //Check if $ctrl has been set with the controller
        expect(scope.$ctrl).toBe(controller);
    });

    it('expect controller to be initialized', function () {
        controller = componentElement.controller(componentName);
        expect(controller.organismos.length).toBe(1);
    });

    it('expect parameter: "organismo" to be set', function () {
        controller = componentElement.controller(componentName);

        //Shouldn´t have a value yet
        expect(controller.organismo).toBeUndefined();

        //Run digest, setting new values in outer scope
        scope.organismo = { intIdOrganismoInternacional: 1 };
        $httpBackend.flush();
        scope.$digest();

        expect(controller.organismo.intIdOrganismoInternacional).toBe(1);

    });

    it('expect parameter: "required" to be set', function () {

        controller = componentElement.controller(componentName);
        //Shouldn´t have a value yet
        expect(controller.required).toBeUndefined();

        //Run digest, setting new values in outer scope
        scope.required = false;
        $httpBackend.flush();
        scope.$digest();

        expect(controller.required).toBe(false);

        //Run digest, setting new values in outer scope
        scope.required = true;
        $httpBackend.flush();
        scope.$digest();

        expect(controller.required).toBe(true);

    });

    it('expect parameter: "cache" to be set', function () {

        //Check Default Value not passing cache
        controller = $componentController(componentName, { $scope: scope });
        $httpBackend.flush();
        scope.$digest();
        expect(controller.cache).toBe(true);
        
        //Run digest, setting new values in outer scope
        controller = componentElement.controller(componentName);
        scope.cache = false;
        scope.$digest();
        expect(controller.cache).toBe(false);

        //Run digest, setting new values in outer scope
        scope.cache = true;
        scope.$digest();
        expect(controller.cache).toBe(true);

    });

    it('expect parameter: "disabled" to be set', function () {
        controller = componentElement.controller(componentName);
        expect(controller.disabled).toBeUndefined();

        scope.disabled = false;
        scope.$digest();
        expect(controller.disabled).toBe(false);

        //Run digest, setting new values in outer scope
        scope.disabled = true;
        scope.$digest();
        expect(controller.disabled).toBe(true);

    });


    it('expect parameter: "organismo" to configure selected value in the list', function () {
        controller = componentElement.controller(componentName);
        scope.organismo = { intIdOrganismoInternacional: 1 };
        $httpBackend.flush();
        scope.$digest();
        expect(controller.selectedItem.strNomeOrganismoInternacional).toBe('Programa das Nações Unidas');

        //Change culture to english
        cultureService.setCulture('en-US');
        $httpBackend.flush();
        scope.$digest();
        expect(controller.selectedItem.strNomeOrganismoInternacional).toBe('United Nations Developing Program');

    });

    it('expect handleExceptionFactory to have been called on failing to load data', function() {
        //To force the controller to init and respond with an error
        cultureService.setCulture('es-ES');
        $httpBackend.flush();
        scope.$digest();
        //Espera ter caido em exceção
        expect(handleExceptionFactory).toHaveBeenCalled();
    });

    //Helper Function
    function getCompiledElement(el) {
        var element = angular.element("<body>" + el + "</body");
        var compiledElement = $compile(element)(scope);
        //On init of the controller has a httpGET so flush it already
        $httpBackend.flush();
        scope.$digest();       
        return compiledElement;
    }

});