﻿(function () {

    'use strict';

     /**
     * @ngdoc overview
     * @name components.organismo.organismoSelect
     * 
     * @description
     *
     * # abcOrganismoSelect - Component #
     *
     * This component is responsible to render a select list with autocomplete will all values of the item 'Organismo Internacional', it is
     * also responsible to change the values based on the current culture
     *
     */
    angular
        .module('components.organismo.organismoSelect', [
            'shared.services.service.organismo',
            'shared.services.service.culture',
            'shared.services.factory.handleException'
        ])


        /**
         * @ngdoc directive
         * @name components.organismo.organismoSelect.directive:abcOrganismoSelect
         * 
         * @restrict 'E'
         * 
         * @param {object=} organismo An object with at least the property 'intIdOrganismoInternacional' to set its value in the select list.
         * @param {boolean=} cache Sets if the controller should cache the data. Defaults to true if not set. It need to be set to false to not cache.
         * @param {boolean=} disabled Sets if the controller should be disabled or not.
         * @param {boolean=} required Sets if the controller is required or not when submitting a form.
         * 
         * @description
         *
         * # abcOrganismoSelect - Component #
         *
         * This component is responsible to render a select list with autocomplete will all values of the item 'Organismo Internacional', it is
         * also responsible to change the values based on the current culture
         *
         */
        .component('abcOrganismoSelect', {
            templateUrl: 'app/components/organismo/organismoSelect/organismoSelect.html',
            controller: OrganismoSelectController,
            bindings: {
                organismo: '=?',
                cache: '<',
                disabled: '<',
                required: '<'
            }
        });


    

    //Inject Dependencies
    OrganismoSelectController.$inject = ['organismoService', 'cultureService', '$scope', 'handleExceptionFactory'];

    /**
     * @ngdoc controller
     * @name components.organismo.organismoSelect.controller:OrganismoSelectController
     *
     * @requires shared.services.service.service:organismo
     * @requires shared.services.service.service:culture
     * @requires shared.services.factory.service:handleException
     *
     * @description
     *
     * It has the logic behind the component
     *
     */
    function OrganismoSelectController(organismoService, cultureService, $scope, handleExceptionFactory) {

        var vm = this;
        vm.organismos = [];

        //Default value
        if (vm.cache === undefined) { vm.cache = true; };
        vm.selectedItemChange = selectedItemChange;

        init();

        /**
        * @ngdoc function
        * @name init
        * @methodOf components.organismo.organismoSelect.controller:OrganismoSelectController
        *
        * @description
        *
        * This is a private function that is called when the controller is initialized and everytime an item or culture is changed
        */
        function init() {
            var queryParams = { strIdCultura: cultureService.getCulture().culture, cache: vm.cache };
            organismoService
                .load(queryParams)
                .then(function (data) {
                    vm.organismos = data;

                    if (!!vm.organismo && vm.organismo.intIdOrganismoInternacional) {
                        var index = _.findIndex(vm.organismos, { intIdOrganismoInternacional: vm.organismo.intIdOrganismoInternacional });
                        if (index > -1) {
                            //Be sure 'organismo' has completed information
                            vm.organismo = vm.organismos[index];

                            //Selects item in the list
                            vm.selectedItem = vm.organismos[index];
                        }
                    }
                })
                .catch(handleExceptionFactory);
        }

        //Listen for culture Changes to update the value in the correct language
        var cultureEvent = cultureService.onCultureChange(init);
        $scope.$on('$destroy', cultureEvent);

        //Watch for changes in the id or required parameters that has been passed
        $scope.$watch(function () {
            var intIdOrganismoInternacional = undefined;
            if (!!vm.organismo && !!vm.organismo.intIdOrganismoInternacional) {
                intIdOrganismoInternacional = vm.organismo.intIdOrganismoInternacional;
            }
            return { intIdOrganismoInternacional: intIdOrganismoInternacional, required: vm.required };
        }, function (newValue, oldValue) {
            // Check if value has changes
            if (newValue === oldValue) {
                return;
            }
            //When values changes, init the controller again
            init();
        }, true);


        /**
        * @ngdoc function
        * @name selectedItemChange
        * @methodOf components.organismo.organismoSelect.controller:OrganismoSelectController
        *
        * @param {object=} item An object with the item, organismo internacional, that has changed
        * @param {reference=} ctrl A reference to the controller, so it can set if it is required or not.
        * 
        * @description
        *
        * Everytime a user changes the selected value this item check if the value is different from the one initial set and if are, update the parameter 'id'.
        * It also sets error messages based if the component is required or not
        * 
        */
        function selectedItemChange(item, ctrl) {
            if (!!item) {
                //Item changed
                if (vm.organismo == undefined || vm.organismo.intIdOrganismoInternacional !== item.intIdOrganismoInternacional) {
                    vm.organismo = item;
                }
                //Set requiredError to not show
                if (!!vm.required) {
                    ctrl.$setValidity("required", true);
                }
            } else {
                //clear value
                vm.organismo = undefined;
                //set required error to show
                if (!!vm.required) {
                    ctrl.$setValidity("required", false);
                }
            }
        }

    }
})();