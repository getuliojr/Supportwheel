﻿(function () {
    'use strict';

    angular
        .module('components.organismo', [
            'components.organismo.organismoSelect'

    ]);

})();

