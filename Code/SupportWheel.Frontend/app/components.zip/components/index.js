﻿(function () {
    'use strict';

    angular
        .module('components', [
        'components.areaGeografica',
        'components.core',
        'components.cultura',
        'components.instituicao',
        'components.organismo',
        'components.pais',
        'components.projeto',
        'components.setor',
        'components.subsetor',
        'components.tipoCooperacao',
        'components.tipoProjeto',
        'components.usuario'

    ]);

})();

