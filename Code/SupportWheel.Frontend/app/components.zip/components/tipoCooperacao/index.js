﻿(function () {
    'use strict';

    angular
        .module('components.tipoCooperacao', [
            'components.tipoCooperacao.tipoCooperacaoSelect'

    ]);

})();

