﻿describe('Component.tipoCooperacao: tipoCooperacaoSelect', function () {

    //Variable for itens that are going to be used in the tests
    var $compile, controllerAs, componentName, componentElement, isolateScope;

    //Load Module to be Tested
    beforeEach(module('components.tipoCooperacao.tipoCooperacaoSelect', 'templates'));

    //Load Services
    beforeEach(module('shared.services.service', 'ngStorage', 'ngMaterial', 'pascalprecht.translate'));

    //Inject Dependencies
    beforeEach(inject(function (_$rootScope_, _$controller_, _$compile_, _$componentController_) {

        //Create new scope
        scope = _$rootScope_.$new();
        //Configure to always start as an empty config
        scope.config = {}; 

        //Inject dependencies
        $compile = _$compile_;

        //Create Component
        var element = '<abc-tipo-cooperacao-select id="id" required="required"></abc-tipo-cooperacao-select>';
        componentElement = getCompiledElement(element);

        //Other variables
        componentName = 'abcTipoCooperacaoSelect';
        isolateScope = componentElement.isolateScope();
        $componentController = _$componentController_;

    }));


    it('expect template to be replaced', function () {
        expect(componentElement.find('md-autocomplete').length).toBe(1);
    });

    it('expect controller to be defined', function () {
        var controller = componentElement.controller(componentName);
        expect(controller).toBeDefined();
    });

    it('expect controller to be initialized', function () {
        var controller = componentElement.controller(componentName);
        expect(controller.tiposCooperacao.length).toBe(3);
    });

    it('expect controller to be attached to the scope as $ctrl', function () {
        controller = $componentController(componentName, { $scope: scope });
        //Check if $ctrl has been set with the controller
        expect(scope.$ctrl).toBe(controller);
    });

    it('expect parameter: "id" to be set', function () {
        //Run digest, setting new values in outer scope
        controller = componentElement.controller(componentName);
        
        expect(controller.id).toBeUndefined(); 
        scope.id = "1";
        scope.$digest();
        expect(controller.id).toBe(scope.id);

        scope.id = undefined;
        scope.$digest();
        expect(controller.id).toBeUndefined();
    });

    it('expect parameter: "required" to be set', function () {
        //Run digest, setting new values in outer scope
        controller = componentElement.controller(componentName);

        expect(controller.required).toBeUndefined();
        scope.required = true;
        scope.$digest();
        expect(controller.required).toBe(scope.required);

        scope.required = undefined;
        scope.$digest();
        expect(controller.required).toBeUndefined();
    });

    it('expect parameter: "id" to configure selected value in the list', function () {
        controller = componentElement.controller(componentName);
        scope.id = "1";
        scope.$digest();
        expect(controller.searchText).toBe('TIPOCOOPERACAO.REGIONAL');

        scope.id = "2";
        scope.$digest();
        expect(controller.searchText).toBe('TIPOCOOPERACAO.BILATERAL');
    });

    //Helper Function
    function getCompiledElement(el){
        var element = angular.element("<body>" + el + "</body");
        var compiledElement = $compile(element)(scope);     
        scope.$digest();       
        return compiledElement;
    }

});