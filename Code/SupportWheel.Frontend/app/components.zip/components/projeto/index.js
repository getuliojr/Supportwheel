﻿(function () {
    'use strict';

    angular
        .module('components.projeto', [
            'components.projeto.projeto.form',
            'components.projeto.projeto.new',
            'components.projeto.projeto.search',
            'components.projeto.projeto.view',
            'components.projeto.projeto-parceiro',
            'components.projeto.projeto-subsetor'
            
    ]);

})();

