﻿describe('Component.Projeto: projetoNew', function () {

    //Variable for itens that are going to be used in the tests
    var $compile, directive, componentName, componentElement, isolateScope;

    //Load Module to be Tested
    beforeEach(module('components.projeto.projeto.new', 'templates'));

    //Load Services
    beforeEach(module('shared.services.service', 'ngStorage', 'ngMaterial', 'pascalprecht.translate'));

    //Load factories (resource, backend)
    beforeEach(module('shared.services.factory', 'ngResource', 'SignalR'));

    //Inject Dependencies
    beforeEach(inject(function (_$rootScope_, _$controller_, _$compile_, _$componentController_) {

        //Create new scope
        scope = _$rootScope_.$new();
        //Configure to always start as an empty config
        scope.config = {}; 

        //Inject dependencies
        $compile = _$compile_;

        //Create Directive
        var element = '<abc-projeto-new></abc-projeto-new>';
        componentElement = getCompiledElement(element);

        //Other variables
        componentName = 'abcProjetoNew';
        isolateScope = componentElement.isolateScope();
        $componentController = _$componentController_;
        

    }));


    it('expect template to be replaced', function () {
        expect(componentElement.find('form').length).toBe(1);
    });

    it('expect controller to be defined', function () {
        var controller = componentElement.controller(componentName);
        expect(controller).toBeDefined();
    });

    it('expect controller to be attached to the scope as $ctrl', function () {
        controller = $componentController(componentName, { $scope: scope });
        //Check if $ctrl has been set with the controller
        expect(scope.$ctrl).toBe(controller);
    });

    it('expect controller to enable or disable partner international organization based on type of cooperation chosen by the user', function () {
        //Run digest, setting new values in outer scope
        controller = componentElement.controller(componentName);

        //All other cases should enable
        expect(controller.desabilitaTipoParceiroOrganismo(null)).toBe(true);
        expect(controller.desabilitaTipoParceiroOrganismo(1)).toBe(true);
        expect(controller.desabilitaTipoParceiroOrganismo(2)).toBe(true);

        //when set to '3', should not disable 
        expect(controller.desabilitaTipoParceiroOrganismo(3)).toBe(false);

    });

    it('expect addSetor to work add item properly', function () {

        //Run digest, setting new values in outer scope
        controller = componentElement.controller(componentName);
        expect(controller.data.projetoSubsetores.length).toBe(0);

        var subsetor = { intIdSetor: 1, intIdSubsetor: 2, strNomeSubsetor: "Teste" };
        controller.addSubsetor(subsetor);
        scope.$digest();

        expect(controller.data.projetoSubsetores.length).toBe(1);
        expect(controller.data.projetoSubsetores[0]).toBe(subsetor);

        //Try to add again, should fail
        controller.addSubsetor(subsetor);
        scope.$digest();
        expect(controller.data.projetoSubsetores.length).toBe(1);

        //Try to add one that is not in the list, should add.        
        subsetor = { intIdSetor: 1, intIdSubsetor: 3, strNomeSubsetor: "Teste 2" };
        controller.addSubsetor(subsetor);
        scope.$digest();

        expect(controller.data.projetoSubsetores.length).toBe(2);
        expect(controller.data.projetoSubsetores[1]).toBe(subsetor);

    });

    it('expect removeSubsetor to remove the item properly', function () {

        //Run digest, setting new values in outer scope
        controller = componentElement.controller(componentName);
        expect(controller.data.projetoSubsetores.length).toBe(0);
        var subsetor1 = { intIdSetor: 1, intIdSubsetor: 1, strNomeSubsetor: "Teste 1" };
        var subsetor2 = { intIdSetor: 1, intIdSubsetor: 2, strNomeSubsetor: "Teste 2" };
        var subsetor3 = { intIdSetor: 1, intIdSubsetor: 3, strNomeSubsetor: "Teste 3" };
        controller.addSubsetor(subsetor1);
        controller.addSubsetor(subsetor2);
        controller.addSubsetor(subsetor3);
        scope.$digest();
        expect(controller.data.projetoSubsetores.length).toBe(3);

        controller.removeSubsetor(subsetor2);
        scope.$digest();
        expect(controller.data.projetoSubsetores.length).toBe(2);
        expect(controller.data.projetoSubsetores[1]).toBe(subsetor3);


        //should not change anything
        controller.removeSubsetor(subsetor2);
        scope.$digest();
        expect(controller.data.projetoSubsetores.length).toBe(2);
        expect(controller.data.projetoSubsetores[1]).toBe(subsetor3);

        controller.removeSubsetor(subsetor1);
        scope.$digest();
        expect(controller.data.projetoSubsetores.length).toBe(1);
        expect(controller.data.projetoSubsetores[0]).toBe(subsetor3);

    });


    it('expect addParceiro to add the item properly', function () {

        //Run digest, setting new values in outer scope
        controller = componentElement.controller(componentName);
        expect(controller.data.projetoParceiros.length).toBe(0);

        var parceiro1 = { intIdPais: 1, strNomeInstituicao: "Teste" };
        var parceiro2 = { intIdOrganismoInternacional: 2, strNomeInstituicao: "Teste 2" }

        controller.addParceiro(parceiro1);
        scope.$digest();
        expect(controller.data.projetoParceiros.length).toBe(1);
        expect(controller.data.projetoParceiros[0]).toBe(parceiro1);


        controller.addParceiro(parceiro2);
        scope.$digest();
        expect(controller.data.projetoParceiros.length).toBe(2);
        expect(controller.data.projetoParceiros[1]).toBe(parceiro2);

        //Try to add again, should fail
        controller.addParceiro(parceiro2);
        scope.$digest();
        expect(controller.data.projetoParceiros.length).toBe(2);
    });

    it('expect updateParceiro to update the item properly', function () {

        //Run digest, setting new values in outer scope
        controller = componentElement.controller(componentName);
        expect(controller.data.projetoParceiros.length).toBe(0);

        var parceiro1 = { intIdPais: 1, strNomeInstituicao: "Teste" };

        controller.addParceiro(parceiro1);
        scope.$digest();
        expect(controller.data.projetoParceiros.length).toBe(1);
        expect(controller.data.projetoParceiros[0]).toBe(parceiro1);

        //update data
        parceiro1 = { intIdPais: 1, strNomeInstituicao: "Teste 3" };
        controller.updateParceiro(parceiro1);
        scope.$digest();
        expect(controller.data.projetoParceiros.length).toBe(1);
        expect(controller.data.projetoParceiros[0]).toBe(parceiro1);

    });

    it('expect removeParceiro to remove the item properly', function () {

        //Run digest, setting new values in outer scope
        controller = componentElement.controller(componentName);
        expect(controller.data.projetoParceiros.length).toBe(0);
        var parceiro1 = { intIdPais: 1, strNomeInstituicao: "Teste" };
        var parceiro2 = { intIdOrganismoInternacional: 2, strNomeInstituicao: "Teste 2" }

        controller.addParceiro(parceiro1);
        controller.addParceiro(parceiro2);
        scope.$digest();
        expect(controller.data.projetoParceiros.length).toBe(2);

        controller.removeParceiro(parceiro1);
        scope.$digest();
        expect(controller.data.projetoParceiros.length).toBe(1);
        expect(controller.data.projetoParceiros[0]).toBe(parceiro2);


        //should not change anything
        controller.removeParceiro(parceiro1);
        scope.$digest();
        expect(controller.data.projetoParceiros.length).toBe(1);
        expect(controller.data.projetoParceiros[0]).toBe(parceiro2);

        controller.removeParceiro(parceiro2);
        scope.$digest();
        expect(controller.data.projetoParceiros.length).toBe(0);

    });


    //Helper Function
    function getCompiledElement(el){
        var element = angular.element("<body>" + el + "</body");
        var compiledElement = $compile(element)(scope);
        scope.$digest();
        return compiledElement;
    }

});