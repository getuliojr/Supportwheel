﻿(function () {

    'use strict';

    /**
    * @ngdoc overview
    * @name components.projeto.projeto.new
    * 
    * @description
    *
    * # abcProjetoParceiroNew - Component #
    *
    */
    angular
        .module('components.projeto.projeto.new', [
            'shared.services.factory.handleException',
            'shared.services.service.culture',
            'shared.services.service.projeto',
            'shared.services.service.viewstate',
            'shared.services.service.notification',
            'shared.services.service.subsetor'
        ])


     /**
     * @ngdoc directive
     * @name components.projeto.projeto.new.directive:abcProjetoNew
     * 
     * @restrict 'E'
     * 
     * @param {object=} projetct An object with a project to be loaded
     * 
     * @description
     *
     * # projetoNew - Component #
     *
     * This component is responsible to render a type of select list with autocomplete will all values of the item 'Organismo Internacional'. 
     * The difference is that when an item is selected it generate a CHIP. Many itens can me selected of even created
     *
     */
    .component('abcProjetoNew', {
        templateUrl: 'app/components/projeto/projeto.new/projeto.new.html',
        controller: ProjetoNewController,
        bindings: {
    
        }
    });


    //Inject Dependencies
    ProjetoNewController.$inject = ['handleExceptionFactory', 'viewstateService', 'notificationService', 'subsetorService', 'cultureService', 'projetoService','$scope', '$location'];


    /**
     * @ngdoc controller
     * @name components.projeto.projeto.new.controller:ProjetoNewController
     *
     * @requires shared.services.service.service:projetoParceiroInstituicao
     * @requires shared.services.factory.service:handleException
     *
     * @description
     *
     * It has the logic behind the component
     *
     */
    function ProjetoNewController(handleExceptionFactory, viewstateService, notificationService, subsetorService, cultureService, projetoService, $scope, $location) {

        var vm = this;

        //To avoid the data to be destroyed in case of a tab change
        vm.data = viewstateService.getView('Projeto');
        vm.data.projetoSubsetores = [];
        vm.data.projetoParceiros = [];


        //Init component
        vm.$onInit = init;

        //PUBLIC API
        vm.addSubsetor = addSubsetor;
        vm.removeSubsetor = removeSubsetor;
        vm.addParceiro = addParceiro;
        vm.updateParceiro = updateParceiro;
        vm.removeParceiro = removeParceiro;
        vm.saveProject = saveProject;
        vm.desabilitaTipoParceiroOrganismo = desabilitaTipoParceiroOrganismo;

        /**
        * @ngdoc function
        * @name init
        * @methodOf  components.projeto.projeto.new.controller:ProjetoNewController
        * @private
        *
        * @description
        *
        * This is a private function that is called when the controller is initialized
        */
        function init() {

            //Responsable to set the culture of the data that is been entered the same as the culture set by the user
            if (vm.data.strIdCultura == undefined) {
                var currentCulture = cultureService.getCulture();
                if (currentCulture != undefined && currentCulture.culture != undefined) {
                    vm.data.strIdCultura = currentCulture.culture;
                }
            }

            //Listen for culture Changes to update the value in the correct language
            var cultureEvent = cultureService.onCultureChange(updateListNames);
            $scope.$on('$destroy', cultureEvent);

            //Responsable to change the data entered and selected by the user already to a new culture set.
            function updateListNames() {
                //If there is setores selected, translate its value to new language
                if (vm.data.projetoSubsetores.length > 0) {
                    subsetorService
                        .load({ cache: true, intIdSetor: vm.data.projetoSubsetores[0].intIdSetor, strIdCultura: cultureService.getCulture().culture })
                        .then(function (data) {
                            for (var a = vm.data.projetoSubsetores.length - 1; a >= 0; a--) {
                                var index = _.findIndex(data, { intIdSubsetor: vm.data.projetoSubsetores[a].intIdSubsetor });
                                if (index > -1){
                                    //Remapeia os valores referentes a nomes
                                    vm.data.projetoSubsetores[a].strNomeSetor = data[index].strNomeSetor;
                                    vm.data.projetoSubsetores[a].strNomeSubsetor = data[index].strNomeSubsetor;
                                }
                            }
                        })
                        .catch(handleExceptionFactory);
                
                }
            }
        };


        
        /**
        * @ngdoc function
        * @name desabilitaTipoParceiroOrganismo
        * @methodOf  components.projeto.projeto.new.controller:ProjetoNewController
        *
        * @param {int} intIdTipoCooperacao Expect an ID containing the value of the "Tipo de Cooperação"
        *
        * @returns {boolean} It returns true when it show show the type of partner Organismo and false when it doesn´t
        *
        * @description
        *
        * This is responsable to enable or not the selection of a partner of the type international organization depending upon on the 'type of cooperation' selected by the user.
        */
        function desabilitaTipoParceiroOrganismo(intIdTipoCooperacao) {
            //Tri-lateral
            if (intIdTipoCooperacao == 3) {
                return false;
            } else {
                return true;
            }
        }

        /**
        * @ngdoc function
        * @name addSubsetor
        * @methodOf  components.projeto.projeto.new.controller:ProjetoNewController
        * @param {object} subsetor Expect an object of the new subsetor that should be added to the list
        *
        * @description
        *
        * This is responsable to add a new subsetor to the list. If it is already on the list it will show an error and will not add.
        */
        function addSubsetor (subsetor) {
            //check if item is not in the list yet
            if (_.findIndex(vm.data.projetoSubsetores, { intIdSubsetor: subsetor.intIdSubsetor }) == -1) {
                //Add new item to the list
                vm.data.projetoSubsetores.push(subsetor);

                //Clean selected item
                vm.subsetor = undefined;
            } else {
                notificationService.show('warning', "PROJETO-NEW.EXISTING-SUBSETOR");
            }
        }

        /**
        * @ngdoc function
        * @name removeSubsetor
        * @methodOf  components.projeto.projeto.new.controller:ProjetoNewController
        * @param {object} subsetor Expect an object of the subsetor that should be removed from the list
        *
        * @description
        *
        * This is responsable to remove a subsetor from the list. 
        */
        function removeSubsetor(item) {
            if (item != undefined) {
                var index = _.findIndex(vm.data.projetoSubsetores, item);
                if (index > -1) {
                    vm.data.projetoSubsetores.splice(index, 1);
                    notificationService.show('success', "PROJETO-NEW.REMOVED-ITEM");
                }
            } else {
                notificationService.show('warning', "PROJETO-NEW.NO-ITEM-TO-REMOVE");
            }
        }

        /**
        * @ngdoc function
        * @name addParceiro
        * @methodOf  components.projeto.projeto.new.controller:ProjetoNewController
        * @param {object} item Expect an object of the new partner that should be added to the list
        *
        * @description
        *
        * This is responsable to add a new partner to the list. If it is already on the list it will show an error and will not add.
        */
        function addParceiro(item) {
            //check if item is not in the list yet
            var index = undefined;
            if (item.intIdPais != undefined) {
                index = _.findIndex(vm.data.projetoParceiros, { intIdPais: item.intIdPais })
            } else {
                index = _.findIndex(vm.data.projetoParceiros, { intIdOrganismoInternacional: item.intIdOrganismoInternacional })
            }
            if ( index == -1) {
                //Add new item to the list
                vm.data.projetoParceiros.push(item);

                //Clean selected item
                //vm.subsetor = undefined;
            } else {
                notificationService.show('warning', "PROJETO-NEW.EXISTING-PARCEIRO");
            }
        }

        /**
        * @ngdoc function
        * @name updateParceiro
        * @methodOf  components.projeto.projeto.new.controller:ProjetoNewController
        * @param {object} item Expect an object of the partner that should be updated in the list
        *
        * @description
        *
        * This is responsable to update the values of a partner that has already been added. 
        */
        function updateParceiro(item) {
            //check if item is not in the list yet
            var index = undefined;
            if (item.intIdPais != undefined) {
                index = _.findIndex(vm.data.projetoParceiros, { intIdPais: item.intIdPais })
            } else {
                index = _.findIndex(vm.data.projetoParceiros, { intIdOrganismoInternacional: item.intIdOrganismoInternacional })
            }
            if (index == -1) {
                notificationService.show('warning', "PROJETO-NEW.NO-PARCEIRO");
            } else {
                //Update values
                vm.data.projetoParceiros[index] = item;

            }
        }


        /**
        * @ngdoc function
        * @name removeParceiro
        * @methodOf  components.projeto.projeto.new.controller:ProjetoNewController
        * @param {object} item Expect an object of the partner that should be removed to the list
        *
        * @description
        *
        * This is responsable to remove a partner from the list. 
        */
        function removeParceiro(item) {
            if (item != undefined) {
                var index = _.findIndex(vm.data.projetoParceiros, item);
                if (index > -1) {
                    vm.data.projetoParceiros.splice(index, 1);
                    notificationService.show('success', "PROJETO-NEW.REMOVED-ITEM");
                }
            } else {
                notificationService.show('warning', "PROJETO-NEW.NO-ITEM-TO-DELETE");
            }
        }

        /**
        * @ngdoc function
        * @name saveProject
        * @methodOf  components.projeto.projeto.new.controller:ProjetoNewController
        * @param {object} project Expect an object of the data of the project that should be saved
        *
        * @description
        *
        * This is responsable to save the project to the database.
        */
        function saveProject(project) {
            var successCB = function (result) {
                notificationService.show('success', "GENERAL.SAVED-SUCCESSFULLY");
                $location.path("project/" + result.intIdProjeto + "/edit");
            }

            projetoService
                .save(project)
                .then(successCB, handleExceptionFactory);
        }

       
    }
})();
