﻿(function () {

    'use strict';

     /**
     * @ngdoc overview
     * @name components.projeto.projeto-subsetor
     * @description
     *
     * # projetoSubsetor - Component #
     *
     * This component is responsable to select one sector and one subsector and add to the project. Once a subsector has been added
     * the component does not allow to change the sector, but the user can still add other subsectors on the same sector.
     *
     * The component is also responsable to translate the value based on the culture.
     *
     * It also accepts a list of sectors and list its value, where the user can remove its values.
     *
     * @example
       <pre>
        <abc-projeto-subsetor 
            on-insert="onInsert" 
            on-delete="onDelete" 
            setor="setor" 
            subsetor="subsetor" 
            subsetores="subsetores">
        </abc-projeto-subsetor>
       </pre>
     */
    angular
        .module('components.projeto.projeto-subsetor', [

        ])

        .directive('abcProjetoSubsetor', projetoSubsetorDirective)
        .controller('ProjetoSubsetorController', ProjetoSubsetorController);

    /**
     * @ngdoc directive
     * @name components.projeto.projeto-subsetor.directive:projetoSubsetor
     *
     * @restrict 'E'
     *
     * @param {object=} setor An object that receives a sector to be selected in the controller. It needs to contain at least the property 'intIdSetor' to work. 
     * It keeps the full sector item in sync with the culture selected
     * @param {object=} subsetor An object that receives a subsector to be selected in the controller. It needs to contain at least the property 'intIdSubsetor' to work. 
     * It keeps the full subsector item in sync with the culture selected
     * @param {array=} subsetores An array containing a list of subsectores to be listed so the user knows all the itens that have been added to the project.
     * @param {function=} on-insert A function that will be called when the user tries to insert a new subsector in the project. If not passed the function to add itens will not be available. It output a parameter of name 'subsetor' if passed.
     * @param {function=} on-delete A function that will be called when the user tries to remove a subsector from the project. If not passed the function to remove an item will not be available.
     *
     * @description
     *
     * This component is responsable to select one sector and one subsector and add to the project. Once a subsector has been added
     * the component does not allow to change the sector, but the user can still add other subsectors on the same sector.
     * The component is also responsable to translate the value based on the culture.
     *
     * It also accepts a list of sectors and list its value, where the user can remove its values.
     *
     */
    function projetoSubsetorDirective() {
        return {
            restrict: 'E',
            controller: 'ProjetoSubsetorController',
            templateUrl: 'app/components/projeto/projeto-subsetor/projeto-subsetor.html',
            controllerAs: 'projetoSubsetor',
            scope: {},
            bindToController: {
                setor: '=?',
                subsetor:'=?',
                subsetores: '=?',
                onInsert: '&?',
                onDelete: '&?',
                readOnly:'<?'
            }
        }
    }


    //Inject Dependencies
    ProjetoSubsetorController.$inject = ['$scope'];

    /**
     * @ngdoc controller
     *
     * @name components.projeto.projeto-subsetor.controller:ProjetoSubsetorController
     *
     * @description
     *
     * All the logic behind the component
     *
     */
    function ProjetoSubsetorController($scope) {

        var vm = this;

        //Configuration for the dataList
        vm.dataListConfig = {
            enableFilter: false,
            enableRowSelection: false,
            columns: [{ field: 'strNomeSubsetor', isNumeric: false, displayName: 'PROJETO-SUBSETOR.SUBSECTORS' }]
        };

        //Init the controller
        init();

        /**
        * @ngdoc function
        * @name init
        * @methodOf components.projeto.projeto-subsetor.controller:ProjetoSubsetorController
        *
        * @description
        *
        * This is a private function that is called when the controller is initialized. It is responsable to check required params and 
        * allowing or not to delete an item.
        */
        function init() {
            if (vm.onInsert != undefined && typeof (vm.onInsert) != "function") {
                console.error("The component: 'projeto-subsetor' expect a function on the parameter: 'on-insert'")
            }

            if (vm.onDelete != undefined && typeof (vm.onDelete) != "function") {
                console.error("The component: 'projeto-subsetor' expect a function on the parameter: 'on-delete'")
            }

            
            if (vm.onDelete != undefined && typeof (vm.onDelete) == "function" && vm.readOnly !== true) {
                //Allows the user to delete if there is a delete function
                vm.dataListConfig.itemMenu = [{
                    name: 'PROJETO-SUBSETOR.DELETE', icon: 'delete', ariaLabel: 'delete', msgConfirm: {},
                    onClick: vm.onDelete
                }];
            } else {
                //Does not allow to delete a item
                vm.dataListConfig.itemMenu = undefined;
            }

            //Se passou uma lista de subsetores, configura o setor com base no setor aqui escolhido
            if (vm.subsetores && vm.subsetores.length > 0) {
                vm.setor = { intIdSetor: vm.subsetores[0].intIdSetor, strNomeSetor: vm.subsetores[0].strNomeSetor };
            }
        }

        //Watch for changes in the property 'parceiro'
        $scope.$watch(function () {
            return { subsetores: vm.subsetores };
        }, function (newValue, oldValue) {
            // Check if value has changes
            if (newValue === oldValue) {
                return;
            }
            //When values changes, init the controller again to parse the values in the component
            init();
        }, true);

    }
})();