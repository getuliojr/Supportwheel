﻿describe('Component.Projeto: projetoSubsetor', function () {

    //Variable for itens that are going to be used in the tests
    var $compile, directive, controllerAs, directiveName, isolateScope;

    //Load Module to be Tested
    beforeEach(module('components.projeto.projeto-subsetor', 'templates'));

    //Load Services
    beforeEach(module('shared.services.service', 'ngStorage', 'ngMaterial', 'pascalprecht.translate'));

    //Inject Dependencies
    beforeEach(inject(function (_$rootScope_, _$controller_, _$compile_) {

        //Create new scope
        scope = _$rootScope_.$new();
        //Configure to always start as an empty config
        scope.config = {}; 

        //Inject dependencies
        $compile = _$compile_;

        //Create Directive
        var directiveElement = '<abc-projeto-subsetor on-insert="onInsert" on-delete="onDelete" setor="setor" subsetor="subsetor" subsetores="subsetores"></abc-projeto-subsetor>';
        directive = getCompiledElement(directiveElement);
        
        //Other variables
        controllerAs = 'projetoSubsetor';
        directiveName = 'abcProjetoSubsetor';
        isolateScope = directive.isolateScope();
        

    }));


    it('expect template to be replaced', function () {
        expect(directive.find('ng-form').length).toBe(1);
    });

    it('expect controller to be defined', function () {
        var controller = directive.controller(directiveName);
        expect(controller).toBeDefined();
    });

    it('expect controllerAs name to be right', function () {
        expect(isolateScope.hasOwnProperty(controllerAs)).toBeTruthy();
    });

    it('expect parameter: "onInsert" to be set', function () {
        var onInsert = function(){};
        scope.onInsert = onInsert;
        var controller = isolateScope[controllerAs];

        //Shouldn´t have a value yet
        expect(controller.onInsert).toBeUndefined();

        //Run digest, setting new values in outer scope
        scope.$digest();

        expect(controller.onInsert).toBe(onInsert);

    });

    it('expect parameter: "onDelete" to be set', function () {
        var onDelete = function () { };
        scope.onDelete = onDelete;
        var controller = isolateScope[controllerAs];

        //Shouldn´t have a value yet
        expect(controller.onDelete).toBeUndefined();

        //Run digest, setting new values in outer scope
        scope.$digest();

        expect(controller.onDelete).toBe(onDelete);

    });

    it('expect parameter: "setor" to be set', function () {
        var setor = {intIdSetor: 1};
        scope.setor = setor;
        var controller = isolateScope[controllerAs];

        //Shouldn´t have a value yet
        expect(controller.setor).toBeUndefined();

        //Run digest, setting new values in outer scope
        scope.$digest();

        expect(controller.setor.intIdSetor).toBe(1);

    });

    it('expect parameter: "subsetor" to be set', function () {
        var subsetor = { intIdSubsetor: 1 };
        scope.subsetor = subsetor;
        var controller = isolateScope[controllerAs];

        //Shouldn´t have a value yet
        expect(controller.subsetor).toBeUndefined();

        //Run digest, setting new values in outer scope
        scope.$digest();

        expect(controller.subsetor.intIdSubsetor).toBe(1);

    });

    //Helper Function
    function getCompiledElement(el){
        var element = angular.element("<body>" + el + "</body");
        var compiledElement = $compile(element)(scope);     
        scope.$digest();       
        return compiledElement;
    }

});