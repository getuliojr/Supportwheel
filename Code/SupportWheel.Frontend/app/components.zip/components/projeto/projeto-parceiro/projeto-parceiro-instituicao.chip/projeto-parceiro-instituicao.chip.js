﻿(function () {

    'use strict';

     /**
     * @ngdoc overview
     * @name components.projeto.projeto-parceiro.projeto-parceiro-instituicao.chip
     * 
     * @description
     *
     * # abcProjetoParceiroInstituicaoChip - Component #
     *
     * This component is responsible to render a type of select list with autocomplete will all values of the item 'Organismo Internacional'. 
     * The difference is that when an item is selected it generate a CHIP. Many itens can me selected of even created
     *
     * - {@link components.projeto.projeto-parceiro.projeto-parceiro.chip.directive:abcProjetoParceiroInstituicaoChip abcProjetoParceiroInstituicaoChip}
     * - {@link components.projeto.projeto-parceiro.projeto-parceiro.chip.controller:ProjetoParceiroInstituicaoController controller}
     */
    angular
        .module('components.projeto.projeto-parceiro.projeto-parceiro-instituicao.chip', [
            'shared.services.service.projetoParceiroInstituicao',
            'shared.services.factory.handleException'
        ])

     /**
     * @ngdoc directive
     * @name components.projeto.projeto-parceiro.projeto-parceiro-instituicao.chip.directive:abcProjetoParceiroInstituicaoChip
     * 
     * @restrict 'E'
     * 
     * @param {object=} instituicoes An object with at least the property 'strNomeInstituicao' to set its value in the list
     * @param {int=} minLength Sets if the mininum number of characters the use has to type in order to initiate a request in the server. The cache is always true and the Default Value is 3 if not set.
     * 
     * @description
     *
     * # projetoParceiroInstituicaoChip - Component #
     *
     * This component is responsible to render a type of select list with autocomplete will all values of the item 'Organismo Internacional'. 
     * The difference is that when an item is selected it generate a CHIP. Many itens can me selected of even created
     *
     */
        .component('abcProjetoParceiroInstituicaoChip', {
            templateUrl: 'app/components/projeto/projeto-parceiro/projeto-parceiro-instituicao.chip/projeto-parceiro-instituicao.chip.html',
            controller: ProjetoParceiroInstituicaoController,
            bindings: {
                instituicoes: '=?',
                minLength: '=?',
            }
        });


    

    //Inject Dependencies
    ProjetoParceiroInstituicaoController.$inject = ['projetoParceiroInstituicaoService', 'handleExceptionFactory'];

    /**
     * @ngdoc controller
     * @name components.projeto.projeto-parceiro.projeto-parceiro-instituicao.chip.controller:ProjetoParceiroInstituicaoController
     *
     * @requires shared.services.service.service:projetoParceiroInstituicao
     * @requires shared.services.factory.service:handleException
     *
     * @description
     *
     * It has the logic behind the component
     *
     */
    function ProjetoParceiroInstituicaoController(projetoParceiroInstituicaoService, handleExceptionFactory) {

        var vm = this;

        //Init component
        vm.$onInit = init;

        //PUBLIC API
        vm.querySearch = querySearch;
        vm.newChip = newChip;

        /**
        * @ngdoc function
        * @name init
        * @methodOf  components.projeto.projeto-parceiro.projeto-parceiro-instituicao.chip.controller:ProjetoParceiroInstituicaoController
        *
        * @description
        *
        * This is a private function that is called when the controller is initialized
        */
        function init() {

            //DEFAULT VALUES IF NOT SET
            if (vm.instituicoes === undefined) {
                vm.instituicoes = [];
            }
            //At least 3 characters must be typed before making a query in the database
            if (vm.minLength === undefined) {
                vm.minLength = 3;
            }
            
        };


        /**
        * @ngdoc function
        * @name querySearch
        * @methodOf components.projeto.projeto-parceiro.projeto-parceiro-instituicao.chip.controller:ProjetoParceiroInstituicaoController
        *
        * @param {string=} strNomeInstituicao A string containing part of the name of a previously added institution.
        * 
        * @description
        *
        * Everytime a user types at least the number of characteres set in the property minLength, it makes a search in the database to return matches of that name.
        * 
        */
        function querySearch(strNomeInstituicao) {
            return projetoParceiroInstituicaoService
                .load({ cache: true, strNomeInstituicao: strNomeInstituicao })
                .catch(handleExceptionFactory);
        }

        /**
       * @ngdoc function
       * @name newChip
       * @methodOf components.projeto.projeto-parceiro.projeto-parceiro-instituicao.chip.controller:ProjetoParceiroInstituicaoController
       *
       * @param {string} chip A string when a new item is been created or an object when it is been selected. This function always return an object containing the field "strNomeInstituicao"
       * 
       * @description
       *
       * Everytime a chip is selected or created, this function is evoqued and return an formatted object.
       * 
       */
        function newChip(chip) {
            //If it is already an object. The item was selected
            if (angular.isObject(chip)) {
                return chip;
            }
            // Otherwise, create a new one
            return { strNomeInstituicao: chip }
        }

    }
})();