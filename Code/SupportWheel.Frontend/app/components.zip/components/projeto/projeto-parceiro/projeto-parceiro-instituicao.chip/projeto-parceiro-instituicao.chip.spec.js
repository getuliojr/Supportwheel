﻿describe('Component.projeto.projeto-parceiro: projeto-parceiro-instituicao.chip', function () {

    //Variable for itens that are going to be used in the tests
    //var $compile, directive, controllerAs, directiveName, isolateScope, cultureService, $httpBackend, mockHandleExceptionFactory;
    var scope, controller, componentName, componentElement, element, $componentController, $compile, $httpBackend, mockHandleExceptionFactory, handleExceptionFactory;

    //Load Module to be Tested
    //Allows to check if the module handleExceptionFactory has been called
    beforeEach(module('components.projeto.projeto-parceiro.projeto-parceiro-instituicao.chip', 'templates', function ($provide) {
        $provide.decorator('handleExceptionFactory', function ($delegate) {
            mockHandleExceptionFactory = jasmine.createSpy('handleExceptionFactory', $delegate).and.callThrough();
            return mockHandleExceptionFactory;
        });
    }));

    //Load Services
    beforeEach(module('shared.services.service', 'ngStorage', 'ngMaterial', 'pascalprecht.translate'));

    //Load factories (resource, backend)
    beforeEach(module('shared.services.factory', 'ngResource', 'SignalR'));

   

    //Inject Dependencies
    beforeEach(inject(function (_$rootScope_, _$compile_, _$httpBackend_, _handleExceptionFactory_, _$componentController_) {

        var mockData = [{ "intIdProjetoParceiroInstituicao": 1, "strNomeInstituicao": "Agencia Brasileira de Cooperação" },
                        { "intIdProjetoParceiroInstituicao": 2, "strNomeInstituicao": "Embrapa" }];

        
        //Create new scope
        scope = _$rootScope_.$new();

        //Configure to always disable cache, required for testing
        scope.cache = false;
        componentName = 'abcProjetoParceiroInstituicaoChip';

        //Inject dependencies
        $httpBackend = _$httpBackend_;
        $compile = _$compile_;
        handleExceptionFactory = _handleExceptionFactory_;
        $componentController = _$componentController_;


        //Mock htppGet
        $httpBackend.whenGET('/asamap/api/projetoParceiroInstituicao?cache=true&strNomeInstituicao=abc').respond(mockData);
        
        element = '<abc-projeto-parceiro-instituicao-chip instituicoes="instituicoes" min-length="minLength"></abc-projeto-parceiro-instituicao-chip>';
        componentElement = getCompiledElement(element);

    }));

    afterEach(function () {
        $httpBackend.verifyNoOutstandingExpectation();
        $httpBackend.verifyNoOutstandingRequest();
    });

    it('expect template to be replaced', function () {
        expect(componentElement.find('md-chips').length).toBe(1);
    });

    it('expect controller to be defined', function () {
        controller = $componentController(componentName, { $scope: scope }, { cache: false });
        expect(controller).toBeDefined();
    });

    it('expect controller to be attached to the scope as $ctrl', function () {
        controller = $componentController(componentName, { $scope: scope });
        //Check if $ctrl has been set with the controller
        expect(scope.$ctrl).toBe(controller);
    });

    it('expect parameter: "instituicoes" to be set', function () {
        //Create a controller to check default value
        controller = componentElement.controller(componentName);
        //Shouldn´t have a value yet
        expect(controller.instituicoes.length).toBe(0);

        //Run digest, setting new values in outer scope
        scope.instituicoes = [{ "strNomeInstituicao": "Embrapa" }, { "strNomeInstituicao": "Agencia Brasileira de Cooperação" }];
        scope.$digest();

        expect(controller.instituicoes.length).toBe(2);

    });

    it('expect parameter: "minLength" to be set', function () {
        
        controller = componentElement.controller(componentName);
        //Shouldn´t have a default value of 3
        expect(controller.minLength).toBe(3);

        //Run digest, setting new values in outer scope
        controller = componentElement.controller(componentName);
        scope.minLength = 5;
        scope.$digest();

        expect(controller.minLength).toBe(5);

    });

    it('expect function "newChip" to generate a complete chip with only a name', function () {
        controller = componentElement.controller(componentName);

        expect(controller.newChip("teste")).toEqual({ strNomeInstituicao: "teste" });
    });

    it('expect function "querySearch" to generate a complete chip with only a name', function () {
        controller = componentElement.controller(componentName);

        controller.querySearch("abc").then(function (data) {
           expect(data.length).toBe(2);
        });

        $httpBackend.flush();
        scope.$digest();
 
    });

    it('expect handleExceptionFactory to have been called on failing to load data on function "querySearch"', function() {

        $httpBackend.whenGET('/asamap/api/projetoParceiroInstituicao?cache=true&strNomeInstituicao=erro').respond(500);

        controller = componentElement.controller(componentName);

        controller.querySearch("erro").then(function (data) {
            //Espera ter caido em exceção
            expect(handleExceptionFactory).toHaveBeenCalled();
        });

        $httpBackend.flush();
        scope.$digest();
        
    });

    //Helper Function
    function getCompiledElement(el) {
        var element = angular.element("<body>" + el + "</body");
        var compiledElement = $compile(element)(scope);
        scope.$digest();
        return compiledElement;
    }

});