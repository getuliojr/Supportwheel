﻿(function () {

    'use strict';

     /**
     * @ngdoc overview
     * @name components.projeto.projeto-parceiro.projeto-parceiro.form
      * 
     * @description
     *
     * # abcProjetoParceiroForm - Component #
     * 
     * This component is responsible to render a form that will list a country or international organization for the user to select,
     * and also a combo box to select or add new institutions to the country/international organization. 
     * More than one institution can be added.
     * 
     * - {@link components.projeto.projeto-parceiro.projeto-parceiro.form.directive:abcProjetoParceiroForm abcProjetoParceiroForm}
     * - {@link components.projeto.projeto-parceiro.projeto-parceiro.form.controller:ProjetoParceiroFormController controller}
     */
    angular
        .module('components.projeto.projeto-parceiro.projeto-parceiro.form', [
        ])

         /**
         * @ngdoc directive
         * @name components.projeto.projeto-parceiro.projeto-parceiro.form.directive:abcProjetoParceiroForm
         * 
         * @restrict 'E'
         * 
         * @param {object=} parceiro If set with data of a parceiro, it will render its value in the component, so the user can edit it.
         * @param {boolean=} allowOnlyCountry If set to true, it will allow to set only a country, otherwise it will show an option to select a country or international organization.
         * @param {function} onSave The user can pass a function that will be called with the 'parceiro' when the button 'SAVE' is clicked. The function must expect a named parameter: 'parceiro' as output.
         * @param {function=} onCancel If set, a cancel button will be draw in the component and will be called when the user clicks on it. If not set no cancel button will be rendered. The function must expect a named parameter: 'parceiro' as output.
         * 
         * @description
         *
         * # abcProjetoParceiroForm - Component #
         *
         * This component is responsible to render a form that will list a country or international organization for the user to select,
         * and also a combo box to select or add new institutions to the country/international organization.
         * More than one institution can be added.
         *
         */
        .component('abcProjetoParceiroForm', {
            templateUrl: 'app/components/projeto/projeto-parceiro/projeto-parceiro.form/projeto-parceiro.form.html',
            controller: ProjetoParceiroFormController,
            bindings: {
                parceiro: '<?',
                allowOnlyCountry: '<?',
                onSave: '&',
                onCancel: '&?'
            }
        });

    //Inject Dependencies
    ProjetoParceiroFormController.$inject = ['$scope'];


    /**
     * @ngdoc controller
     * @name components.projeto.projeto-parceiro.projeto-parceiro.form.controller:ProjetoParceiroFormController
     *
     * @description
     *
     * It has the logic behind the component
     *
     */
    function ProjetoParceiroFormController($scope) {

        var vm = this;


        //Set to allow country by default when the options is given to the user
        vm.tipoParceiro = "pais";

        //Public API
        vm.disableSubmit = disableSubmit;
        vm.save = save;
        
        init(vm.parceiro);

        /**
        * @ngdoc function
        * @name init
        * @methodOf components.projeto.projeto-parceiro.projeto-parceiro.form.controller:ProjetoParceiroFormController
        *
        * @description
        *
        * This is a private function that is called when the controller is initialized and everytime the item parceiro changes by the user.
        * It is responsable to parse the property 'parceiro' to the format the component expects
        */
        function init(parceiro) {
            //Copy data to not make reference to the original value
            var _parceiro = angular.copy(parceiro);

            //If a country has been passed, set it
            if (_parceiro && _parceiro.intIdPais) {
                vm.tipoParceiro = "pais";
                vm.pais = {
                    intIdPais: _parceiro.intIdPais,
                    strNomePais: _parceiro.strNomePais
                }

                //check for culture Id
                if (_parceiro.strIdCultura) {
                    vm.pais.strIdCultura = _parceiro.strIdCultura;
                }

                //check for Id of Geografica Area
                if (_parceiro.intIdAreaGeografica) {
                    vm.pais.intIdAreaGeografica = _parceiro.intIdAreaGeografica;
                }

                //check for Name of Geographic area
                if (_parceiro.strNomeAreaGeografica) {
                    vm.pais.strNomeAreaGeografica = _parceiro.strNomeAreaGeografica;
                }

                //clear organismo
                vm.organismo = undefined;
            } else if (_parceiro && _parceiro.intIdOrganismoInternacional) {
                //If an International organization has been passed
                vm.tipoParceiro = "organismo";
                vm.organismo = {
                    intIdOrganismoInternacional: _parceiro.intIdOrganismoInternacional,
                    strNomeOrganismoInternacional: _parceiro.strNomeOrganismoInternacional
                }

                //check for culture Id
                if (_parceiro.strIdCultura) {
                    vm.organismo.strIdCultura = _parceiro.strIdCultura;
                }

                //clear pais
                vm.pais = undefined;
            } else {
                //clear both
                vm.pais = undefined;
                vm.organismo = undefined;
            }

            //Set instituicoes
            if (_parceiro && _parceiro.projetoParceiroInstituicoes) {
                vm.instituicoes = _parceiro.projetoParceiroInstituicoes;
            }
            
        }


        /**
        * @ngdoc function
        * @name disableSubmit
        * @methodOf components.projeto.projeto-parceiro.projeto-parceiro.form.controller:ProjetoParceiroFormController
        * @returns {boolean} It returns true when the button should be disabled or false when not.
        *
        * @param {string=} tipoParceiro Expect a string containing "pais" or "organismo"
        * 
        * @description
        *
        * It disables the 'SAVE' button based on the selection of a country or international organization not set.
        * 
        */
        function disableSubmit(tipoParceiro) {
            if (tipoParceiro === "pais") {
                //if the view is 'pais' and it is not selected do not allow to submit
                if (vm.pais === undefined) {
                    return true;
                }
            } else {
                //if the view is 'organismo' and it is not selected do not allow to submit
                if (vm.organismo === undefined) {
                    return true;
                }
            }
            //do not disable
            return false;
        }


        /**
        * @ngdoc function
        * @name save
        * @methodOf components.projeto.projeto-parceiro.projeto-parceiro.form.controller:ProjetoParceiroFormController
        * 
        * @description
        *
        * It gets the data and send it over throught the function passed in the property 'onInsert'.
        * 
        */
        function save() {
            var data = generatePartnerObject();

            if (vm.onSave != undefined) {
                if (vm.parceiro == undefined) {
                    vm.parceiro = {};
                }
                angular.extend(vm.parceiro, data);
                vm.onSave({ parceiro: data });
            }
        }
      
        /**
        * @ngdoc function
        * @name generatePartnerObject
        * @methodOf components.projeto.projeto-parceiro.projeto-parceiro.form.controller:ProjetoParceiroFormController
        * @returns {object} It returns an object with the data of 'projeto-parceiro'.
         * 
        * @description
        *
        * It generates the data object that needs to be sent through the component.
        * 
        */
        function generatePartnerObject() {
            var data = {};
            if (vm.tipoParceiro === "pais") {
                angular.extend(data, vm.pais);
            } else {
                angular.extend(data, vm.organismo);
            }

            //Check if there is any institution set and create the colletion
            if (vm.instituicoes) {
               
                data.projetoParceiroInstituicoes = [];
                for(var a = vm.instituicoes.length - 1; a>=0; a--){
                    //Parse institution data
                    var instituicao = {
                        strNomeInstituicao: vm.instituicoes[a].strNomeInstituicao
                    }

                    if (vm.instituicoes[a].intIdProjetoParceiroInstituicao) {
                        instituicao.intIdProjetoParceiroInstituicao = vm.instituicoes[a].intIdProjetoParceiroInstituicao;
                    }


                    //add id of the parceiro, if it exists
                    if (vm.parceiro && vm.parceiro.intIdProjetoParceiro) {
                        instituicao.intIdProjetoParceiro = vm.parceiro.intIdProjetoParceiro;
                    }
                    //push data to the colletion
                    data.projetoParceiroInstituicoes.push(instituicao);
                }
            }

            //Check if a previous record was passed to complete missing parts
            if (vm.parceiro) {
                data.intIdProjetoParceiro = vm.parceiro.intIdProjetoParceiro;
                data.intIdProjeto = vm.parceiro.intIdProjeto;
            }
            
            //Return created formatted data
            return data;
        }


        //Watch for changes in the property 'parceiro'
        $scope.$watch(function () {
            return { parceiro: vm.parceiro};
        }, function (newValue, oldValue) {
            // Check if value has changes
            if (newValue === oldValue) {
                return;
            }
            //When values changes, init the controller again to parse the values in the component
            init(vm.parceiro);
        }, true);
    }
})();