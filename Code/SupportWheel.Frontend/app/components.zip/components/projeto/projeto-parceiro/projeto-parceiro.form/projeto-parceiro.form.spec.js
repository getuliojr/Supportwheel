﻿describe('Component.projeto.projeto-parceiro: projeto-parceiro.form', function () {

    //Variable for itens that are going to be used in the tests
    //var $compile, directive, controllerAs, directiveName, isolateScope, cultureService, $httpBackend, mockHandleExceptionFactory;
    var scope, controller, componentName, componentElement, element, $componentController, $compile, $httpBackend;


    //Load Module to be Tested
    beforeEach(module('components.projeto.projeto-parceiro.projeto-parceiro.form', 'templates'));

    //Load Services
    beforeEach(module('shared.services.service', 'ngStorage', 'ngMaterial', 'pascalprecht.translate'));

    //Inject Dependencies
    beforeEach(inject(function (_$rootScope_, _$compile_, _$componentController_) {
     
        //Create new scope
        scope = _$rootScope_.$new();

        componentName = 'abcProjetoParceiroForm';

        //Inject dependencies
        $compile = _$compile_;
        $componentController = _$componentController_;
        
        element = '<abc-projeto-parceiro-form parceiro="parceiro" allow-only-country="allowOnlyCountry" on-save="onSave(parceiro)" on-cancel="onCancel(parceiro)"></abc-projeto-parceiro-form>';
        componentElement = getCompiledElement(element);

    }));

    it('expect template to be replaced', function () {
        expect(componentElement.find('abc-projeto-parceiro-instituicao-chip').length).toBe(1);
    });

    it('expect controller to be defined', function () {
        controller = $componentController(componentName, { $scope: scope });
        expect(controller).toBeDefined();
    });

    it('expect controller to be attached to the scope as $ctrl', function () {
        controller = $componentController(componentName, { $scope: scope });
        //Check if $ctrl has been set with the controller
        expect(scope.$ctrl).toBe(controller);
    });

    it('expect property: "parceiro" to be set', function () {

        //Run digest, setting new values in outer scope
        controller = componentElement.controller(componentName);
        expect(controller.parceiro).toBeUndefined();

        scope.parceiro = {intIdPais: 1}
        scope.$digest();
        expect(controller.parceiro).toBe(scope.parceiro);

        scope.parceiro = undefined;
        scope.$digest();
        expect(controller.parceiro).toBeUndefined();

    });


    it('expect parameter: "allowOnlyCountry" to be set', function () {

        //Run digest, setting new values in outer scope
        controller = componentElement.controller(componentName);
        expect(controller.allowOnlyCountry).toBeUndefined();

        scope.allowOnlyCountry = true;
        scope.$digest();
        expect(controller.allowOnlyCountry).toBe(true);
        
        scope.allowOnlyCountry = false;
        scope.$digest();
        expect(controller.allowOnlyCountry).toBe(false);

    });

    it('expect parameter: "onInsert" to be set', function () {
        //Create a controller, because when it is of type function '&', the Angular create a local function to reference it
        controller = $componentController(componentName, { $scope: scope });
        scope.$digest();
        expect(controller.onSave).toBeUndefined();
        
        //Run digest, setting new values in outer scope
        controller = $componentController(componentName, { $scope: scope }, { onSave: function () { return 1; } });
        expect(controller.onSave()).toBe(1);

    });

    it('expect parameter: "onCancel" to be set', function () {
        //Create a controller, because when it is of type function '&', the Angular create a local function to reference it
        controller = $componentController(componentName, { $scope: scope });
        scope.$digest();
        expect(controller.onCancel).toBeUndefined();

        //Run digest, setting new values in outer scope
        controller = $componentController(componentName, { $scope: scope }, { onCancel: function () { return 1; } });
        expect(controller.onCancel()).toBe(1);

    });

    it('expect function: "disableSubmit" to return the right values based on the type of partner set', function () {
        controller = componentElement.controller(componentName);

        controller.tipoParceiro = "pais";

        //Since no country is selected it should return false
        expect(controller.disableSubmit(controller.tipoParceiro)).toBe(true);

        //set a country and it should allow submit
        controller.pais = { intIdPais: 1 };
        scope.$digest();
        expect(controller.disableSubmit(controller.tipoParceiro)).toBe(false);

        //Since no organismo is selected, should return true, to disable button
        controller.tipoParceiro = "organismo";
        scope.$digest();
        expect(controller.disableSubmit(controller.tipoParceiro)).toBe(true);

        //set a organimos and it should allow submit
        controller.organismo = { intIdOrganismoInternacional: 1 };
        scope.$digest();
        expect(controller.disableSubmit(controller.tipoParceiro)).toBe(false);
    });

    it('expect function: "onSave" to be called when the function "save" is executed', function () {

        scope.onSave = function(data) { return data; };

        //Create Component
        componentElement = getCompiledElement(element);
        controller = componentElement.controller(componentName);
        spyOn(controller, "onSave");
        

        //Call save function
        controller.save();

        expect(controller.onSave).toHaveBeenCalled();
        
    });

    it('expect function: "Save" to work when the property "parceiro" is set and the the use is trying to add an organismo', function () {

        var dataToSave = {};
        //data to render in the component
        var parceiro = {
            intIdProjetoParceiro: 1, intIdProjeto: 2, intIdOrganismoInternacional: 3, strNomeOrganismoInternacional: 'Organismo',
            projetoparceiroinstituicoes: [{ intIdProjetoParceiroInstituicao: 4, intIdProjetoParceiro: 1, strNomeInstituicao: 'instituicao1' }]
        }

        scope.onSave = function (data) { dataToSave = data; };
        scope.parceiro = parceiro;

        //Create Component
        componentElement = getCompiledElement(element);
        controller = componentElement.controller(componentName);

        controller.tipoParceiro = 'organismo';

        //Call save function
        controller.save();

        //Default to pais so the answer should not have institution
        expect(dataToSave).toEqual({
            intIdProjetoParceiro: 1,
            intIdProjeto: 2,
            intIdOrganismoInternacional: 3,
            strNomeOrganismoInternacional: 'Organismo',
            projetoparceiroinstituicoes: [{ intIdProjetoParceiroInstituicao: 4, intIdProjetoParceiro: 1, strNomeInstituicao: 'instituicao1' }]
        });

    });

    it('expect function: "Save" to work when the property "parceiro" is set and the the use is trying to add a new pais', function () {

        var dataToSave = {};
        //data to render in the component
        var parceiro = {
            intIdProjetoParceiro: 1, intIdProjeto: 2, intIdOrganismoInternacional: 3, strNomeOrganismoInternacional: 'Organismo',
            projetoparceiroinstituicoes: [{ intIdProjetoParceiroInstituicao: 4, intIdProjetoParceiro: 1, strNomeInstituicao: 'instituicao1' }]
        }
        
        scope.onSave = function (data) { dataToSave = data; };
        scope.parceiro = parceiro;

        //Create Component
        componentElement = getCompiledElement(element);
        controller = componentElement.controller(componentName);

        //Simulate the data as the user has select a country
        controller.pais = { intIdPais: 3, strNomePais: 'TestePais' };
        controller.tipoParceiro = 'pais';

        //Call save function
        controller.save();

        //Default to pais so the answer should not have institution
        expect(dataToSave).toEqual({
            intIdProjetoParceiro: 1,
            intIdProjeto: 2,
            intIdPais: 3,
            strNomePais: 'TestePais',
            projetoparceiroinstituicoes: [{ intIdProjetoParceiroInstituicao: 4, intIdProjetoParceiro: 1, strNomeInstituicao: 'instituicao1' }]
        });

    });

    it('expect function: "Save" to work when there is no institution set', function () {

        var dataToSave = {};
        //data to render in the component
        var parceiro = {
            intIdProjetoParceiro: 1, intIdProjeto: 2, intIdOrganismoInternacional: 3, strNomeOrganismoInternacional: 'Organismo',
            projetoparceiroinstituicoes: [{ intIdProjetoParceiroInstituicao: 4, intIdProjetoParceiro: 1, strNomeInstituicao: 'instituicao1' }]
        }

        scope.onSave = function (data) { dataToSave = data; };
        scope.parceiro = parceiro;

        //Create Component
        componentElement = getCompiledElement(element);
        controller = componentElement.controller(componentName);

        controller.instituicoes = undefined;

        //Call save function
        controller.save();

        //It will set as organismo since it has intIdOrganismoInternacional
        expect(dataToSave).toEqual({
            intIdProjetoParceiro: 1,
            intIdProjeto: 2,
            intIdOrganismoInternacional: 3,
            strNomeOrganismoInternacional: 'Organismo'
        });

    });


    //Helper Function
    function getCompiledElement(el) {
        var element = angular.element("<body>" + el + "</body");
        var compiledElement = $compile(element)(scope);
        scope.$digest();       
        return compiledElement;
    }

});