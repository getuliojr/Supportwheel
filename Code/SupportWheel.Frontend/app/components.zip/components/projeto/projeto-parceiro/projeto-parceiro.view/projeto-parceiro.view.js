﻿(function () {

    'use strict';

     /**
     * @ngdoc overview
     * @name components.projeto.projeto-parceiro.projeto-parceiro.view
      * 
     * @description
     *
     * # abcProjetoParceiroView - Component #
     * 
     * This component is responsible to render the information about a single partner in the project.
     * 
     * - {@link components.projeto.projeto-parceiro.projeto-parceiro.view.directive:abcProjetoParceiroView abcProjetoParceiroView}
     * - {@link components.projeto.projeto-parceiro.projeto-parceiro.view.controller:ProjetoParceiroViewController controller}
     */
    angular
        .module('components.projeto.projeto-parceiro.projeto-parceiro.view', [
        ])

         /**
         * @ngdoc directive
         * @name components.projeto.projeto-parceiro.projeto-parceiro.view.directive:abcProjetoParceiroView
         * 
         * @restrict 'E'
         * 
         * @param {boolean=} allowEdit A boolean that check if it should render an edit button or not for the record
         * @param {boolean=} allowDelete A boolean that check if it should render an remove button or not for the record
         * @param {function=} onEdit A function that will receive the new edited object: 'parceiro' when the user clicks on save. The function must have a named parameter 'parceiro' to receive its value.
         * @param {function=} onDelete A function that will receive the original object: 'parceiro' when the user clicks on cancel. The function must have a named parameter 'parceiro' to receive its value.
         * @param {object} parceiro An object containing the information about a single partner and its institutions
         * 
         * @description
         *
         * # abcProjetoParceiroView - Component #
         *
         * This component is responsible to render the information about a single partner in the project.
         *
         */
        .component('abcProjetoParceiroView', {
            templateUrl: 'app/components/projeto/projeto-parceiro/projeto-parceiro.view/projeto-parceiro.view.html',
            controller: ProjetoParceiroViewController,
            bindings: {
                allowEdit: '<?',
                allowDelete: '<?',
                onEdit: '&?',
                onDelete: '&?',
                parceiro: '<'
            }
        });


    /**
     * @ngdoc controller
     * @name components.projeto.projeto-parceiro.projeto-parceiro.view.controller:ProjetoParceiroViewController
     *
     * @description
     *
     * It has the logic behind the component
     *
     */
    function ProjetoParceiroViewController() {
        var vm = this;

    }

})();