﻿describe('Component.projeto.projeto-parceiro: projeto-parceiro.view', function () {

    //Variable for itens that are going to be used in the tests
    //var $compile, directive, controllerAs, directiveName, isolateScope, cultureService, $httpBackend, mockHandleExceptionFactory;
    var scope, controller, componentName, componentElement, $componentController, $compile, $httpBackend;


    //Load Module to be Tested
    beforeEach(module('components.projeto.projeto-parceiro.projeto-parceiro.view', 'templates'));

    //Load Services
    beforeEach(module('shared.services.service', 'ngStorage', 'ngMaterial', 'pascalprecht.translate'));

    //Inject Dependencies
    beforeEach(inject(function (_$rootScope_, _$compile_, _$componentController_) {
     
        //Create new scope
        scope = _$rootScope_.$new();

        componentName = 'abcProjetoParceiroView';

        //Inject dependencies
        $compile = _$compile_;
        $componentController = _$componentController_;

        componentElement = '<abc-projeto-parceiro-view parceiro="parceiro" on-edit="onEdit" allow-edit="allowEdit" allow-delete="allowDelete" on-delete="onDelete"></abc-projeto-parceiro-view>';
        componentElement = getCompiledElement(componentElement);

    }));

    it('expect template to be replaced', function () {
        expect(componentElement.find('md-card').length).toBe(1);
    });

    it('expect controller to be defined', function () {
        controller = componentElement.controller(componentName);
        expect(controller).toBeDefined();
    });

    it('expect controller to be attached to the scope as $ctrl', function () {
        controller = $componentController(componentName, { $scope: scope });
        //Check if $ctrl has been set with the controller
        expect(scope.$ctrl).toBe(controller);
    });

    it('expect property: "parceiro" to be set', function () {

        //Run digest, setting new values in outer scope
        controller = componentElement.controller(componentName);
        expect(controller.parceiro).toBeUndefined();

        scope.parceiro = {intIdPais: 1}
        scope.$digest();
        expect(controller.parceiro).toBe(scope.parceiro);

        scope.parceiro = undefined;
        scope.$digest();
        expect(controller.parceiro).toBeUndefined();

    });

    it('expect parameter: "allowEdit" to be set', function () {

        //Run digest, setting new values in outer scope
        controller = componentElement.controller(componentName);
        expect(controller.allowEdit).toBeUndefined();

        scope.allowEdit = true;
        scope.$digest();
        expect(controller.allowEdit).toBe(true);

        scope.allowEdit = false;
        scope.$digest();
        expect(controller.allowEdit).toBe(false);

    });

    it('expect parameter: "allowDelete" to be set', function () {

        //Run digest, setting new values in outer scope
        controller = componentElement.controller(componentName);
        expect(controller.allowDelete).toBeUndefined();

        scope.allowDelete = true;
        scope.$digest();
        expect(controller.allowDelete).toBe(true);

        scope.allowDelete = false;
        scope.$digest();
        expect(controller.allowDelete).toBe(false);

    });

    it('expect parameter: "onEdit" to be set', function () {
        //Create a controller, because when it is of type function '&', the Angular create a local function to reference it
        controller = $componentController(componentName, { $scope: scope });
        scope.$digest();
        expect(controller.onEdit).toBeUndefined();

        //Run digest, setting new values in outer scope
        controller = $componentController(componentName, { $scope: scope }, { onEdit: function () { return 1; } });
        expect(controller.onEdit()).toBe(1);

    });

    it('expect parameter: "onDelete" to be set', function () {
        //Create a controller, because when it is of type function '&', the Angular create a local function to reference it
        controller = $componentController(componentName, { $scope: scope });
        scope.$digest();
        expect(controller.onDelete).toBeUndefined();

        //Run digest, setting new values in outer scope
        controller = $componentController(componentName, { $scope: scope }, { onDelete: function () { return 1; } });
        expect(controller.onDelete()).toBe(1);

    });

    //Helper Function
    function getCompiledElement(el) {
        var element = angular.element("<body>" + el + "</body");
        var compiledElement = $compile(element)(scope);
        scope.$digest();       
        return compiledElement;
    }

});