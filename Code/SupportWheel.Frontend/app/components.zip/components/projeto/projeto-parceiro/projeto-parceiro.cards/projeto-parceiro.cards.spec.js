﻿describe('Component.projeto.projeto-parceiro: projeto-parceiro.cards', function () {

    //Variable for itens that are going to be used in the tests
    //var $compile, directive, controllerAs, directiveName, isolateScope, cultureService, $httpBackend, mockHandleExceptionFactory;
    var scope, controller, componentName, componentElement, element, $componentController, $compile, $httpBackend;


    //Load Module to be Tested
    beforeEach(module('components.projeto.projeto-parceiro.projeto-parceiro.cards', 'templates'));

    //Load Services
    beforeEach(module('shared.services.service', 'ngStorage', 'ngMaterial', 'pascalprecht.translate'));

    //Inject Dependencies
    beforeEach(inject(function (_$rootScope_, _$compile_, _$componentController_) {
     
        //Create new scope
        scope = _$rootScope_.$new();

        componentName = 'abcProjetoParceiroCards';

        //Inject dependencies
        $compile = _$compile_;
        $componentController = _$componentController_;
        
        element = '<abc-projeto-parceiro-cards parceiros="parceiros" allow-new="allowNew" allow-edit="allowEdit" allow-delete="allowDelete" allow-only-country="allowOnlyCountry" on-new="onNew(parceiro)" on-update="onUpdate(parceiro)" on-delete="onDelete(parceiro)"></abc-projeto-parceiro-cards>';
        componentElement = getCompiledElement(element);

    }));

    it('expect template to be replaced', function () {
        expect(componentElement.find('md-toolbar').length).toBe(1);
    });

    it('expect controller to be defined', function () {
        controller = $componentController(componentName, { $scope: scope });
        expect(controller).toBeDefined();
    });

    it('expect controller to be attached to the scope as $ctrl', function () {
        controller = $componentController(componentName, { $scope: scope });
        //Check if $ctrl has been set with the controller
        expect(scope.$ctrl).toBe(controller);
    });

    it('expect property: "parceiros" to be set', function () {

        //Run digest, setting new values in outer scope
        controller = componentElement.controller(componentName);
        expect(controller.parceiros).toBeUndefined();

        scope.parceiros = {intIdPais: 1}
        scope.$digest();
        expect(controller.parceiros).toBe(scope.parceiros);

        scope.parceiros = undefined;
        scope.$digest();
        expect(controller.parceiros).toBeUndefined();

    });

    it('expect parameter: "allowNew" to be set', function () {

        //Run digest, setting new values in outer scope
        controller = componentElement.controller(componentName);
        expect(controller.allowNew).toBeUndefined();

        scope.allowNew = true;
        scope.$digest();
        expect(controller.allowNew).toBe(true);

        scope.allowNew = false;
        scope.$digest();
        expect(controller.allowNew).toBe(false);

    });

    it('expect parameter: "allowEdit" to be set', function () {

        //Run digest, setting new values in outer scope
        controller = componentElement.controller(componentName);
        expect(controller.allowEdit).toBeUndefined();

        scope.allowEdit = true;
        scope.$digest();
        expect(controller.allowEdit).toBe(true);

        scope.allowEdit = false;
        scope.$digest();
        expect(controller.allowEdit).toBe(false);

    });

    it('expect parameter: "allowDelete" to be set', function () {

        //Run digest, setting new values in outer scope
        controller = componentElement.controller(componentName);
        expect(controller.allowDelete).toBeUndefined();

        scope.allowDelete = true;
        scope.$digest();
        expect(controller.allowDelete).toBe(true);

        scope.allowDelete = false;
        scope.$digest();
        expect(controller.allowDelete).toBe(false);

    });

    it('expect parameter: "allowOnlyCountry" to be set', function () {

        //Run digest, setting new values in outer scope
        controller = componentElement.controller(componentName);
        expect(controller.allowOnlyCountry).toBeUndefined();

        scope.allowOnlyCountry = true;
        scope.$digest();
        expect(controller.allowOnlyCountry).toBe(true);

        scope.allowOnlyCountry = false;
        scope.$digest();
        expect(controller.allowOnlyCountry).toBe(false);

    });

    it('expect function: "onNew" to be set', function () {

        //Create a controller, because when it is of type function '&', the Angular create a local function to reference it
        controller = $componentController(componentName, { $scope: scope });
        scope.$digest();
        expect(controller.onNew).toBeUndefined();

        //Run digest, setting new values in outer scope
        controller = $componentController(componentName, { $scope: scope }, { onNew: function () { return 1; } });
        expect(controller.onNew()).toBe(1);

    });

    it('expect function: "onUpdate" to be set', function () {

        //Create a controller, because when it is of type function '&', the Angular create a local function to reference it
        controller = $componentController(componentName, { $scope: scope });
        scope.$digest();
        expect(controller.onUpdate).toBeUndefined();

        //Run digest, setting new values in outer scope
        controller = $componentController(componentName, { $scope: scope }, { onUpdate: function () { return 1; } });
        expect(controller.onUpdate()).toBe(1);

    });

    it('expect function: "onDelete" to be set', function () {

        //Create a controller, because when it is of type function '&', the Angular create a local function to reference it
        controller = $componentController(componentName, { $scope: scope });
        scope.$digest();
        expect(controller.onDelete).toBeUndefined();

        //Run digest, setting new values in outer scope
        controller = $componentController(componentName, { $scope: scope }, { onDelete: function () { return 1; } });
        expect(controller.onDelete()).toBe(1);

    });

    it('expect function: "edit" to add the item to te list of edited partners', function () {

        //example data
        var parceiro = {
            intIdProjetoParceiro: 1, intIdProjeto: 2, intIdOrganismoInternacional: 3, strNomeOrganismoInternacional: 'Organismo',
            projetoparceiroinstituicoes: [{ intIdProjetoParceiroInstituicao: 4, intIdProjetoParceiro: 1, strNomeInstituicao: 'instituicao1' }]
        }

        //Create Component
        controller = componentElement.controller(componentName);
        expect(controller.isEditing(parceiro)).toBe(false);

        //ask to edit the item
        controller.edit(parceiro);
        scope.$digest();
        expect(controller.isEditing(parceiro)).toBe(true);

    });


    it('expect function: "cancelEdit" to remove the item to te list of edited partners', function () {

        //example data
        var parceiro = {
            intIdProjetoParceiro: 1, intIdProjeto: 2, intIdOrganismoInternacional: 3, strNomeOrganismoInternacional: 'Organismo',
            projetoparceiroinstituicoes: [{ intIdProjetoParceiroInstituicao: 4, intIdProjetoParceiro: 1, strNomeInstituicao: 'instituicao1' }]
        }

        //Create Component
        controller = componentElement.controller(componentName);
        controller.edit(parceiro);
        expect(controller.isEditing(parceiro)).toBe(true);

        controller.cancelEdit(parceiro);
        expect(controller.isEditing(parceiro)).toBe(false);

    });

    it('expect function: "onNew" to be called when the user save a new record', function () {

        //example data
        var parceiro = {
            intIdProjetoParceiro: 1, intIdProjeto: 2, intIdOrganismoInternacional: 3, strNomeOrganismoInternacional: 'Organismo',
            projetoparceiroinstituicoes: [{ intIdProjetoParceiroInstituicao: 4, intIdProjetoParceiro: 1, strNomeInstituicao: 'instituicao1' }]
        }

        scope.onNew = function (data) { return data; }
        scope.$digest();

        //Create Component
        componentElement = getCompiledElement(element);
        controller = componentElement.controller(componentName);
        spyOn(controller, "onNew");

        //call saveNew function
        controller.save(parceiro);
        expect(controller.onNew).toHaveBeenCalled();
        expect(controller.onNew).toHaveBeenCalledWith({ parceiro: parceiro });

    });

    //Helper Function
    function getCompiledElement(el) {
        var element = angular.element("<body>" + el + "</body");
        var compiledElement = $compile(element)(scope);
        scope.$digest();       
        return compiledElement;
    }

});