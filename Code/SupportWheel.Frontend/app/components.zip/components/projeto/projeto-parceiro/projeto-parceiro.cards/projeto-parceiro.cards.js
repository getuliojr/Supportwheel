﻿(function () {

    'use strict';

     /**
     * @ngdoc overview
     * @name components.projeto.projeto-parceiro.projeto-parceiro.cards
      * 
     * @description
     *
     * # abcProjetoParceiroCards - Component #
     * 
     * This component is responsible to render a list of partners of the project as cards.
     * 
     * - {@link components.projeto.projeto-parceiro.projeto-parceiro.cards.directive:abcProjetoParceiroCards abcProjetoParceiroCards}
     * - {@link components.projeto.projeto-parceiro.projeto-parceiro.cards.controller:ProjetoParceiroCardsController controller}
     */
    angular
        .module('components.projeto.projeto-parceiro.projeto-parceiro.cards', [
        ])

         /**
         * @ngdoc directive
         * @name components.projeto.projeto-parceiro.projeto-parceiro.cards.directive:abcProjetoParceiroCards
         * 
         * @restrict 'E'
         * 
         * @param {array=} parceiros An array containing a list of partners and its institutions
         * @param {boolean=} allowNew A boolean value that allow to add new partner or not.
         * @param {boolean=} allowEdit A boolean value that allow to edit a partner or not.
         * @param {boolean=} allowDelete A boolean value that allow to delete a partner or not.
         * @param {boolean=} allowOnlyCountry A boolean value that if set to true allows to select only a country and not an international organization
         * @param {function=} OnNew Output: If allowNew is set to true it will send information of the partner been saved through the function that is setted here. The function must have a named parameter: 'parceiro' to receive its value.
         * @param {function=} OnUpdate Output: If allowEdit is set to true it will send information of the partner been saved through the function that is setted here. The function must have a named parameter: 'parceiro' to receive its value.
         * @param {function=} onDelete Output: If allowDelete is set to true it will send information of the partner that is been requested to deleted through the function that is setted here. The function must have a named parameter: 'parceiro' to receive its value.
         * 
         * @description
         *
         * # abcProjetoParceiroCards - Component #
         *
         * This component is responsible to render a list of partners of the project as cards.
         *
         */
        .component('abcProjetoParceiroCards', {
            templateUrl: 'app/components/projeto/projeto-parceiro/projeto-parceiro.cards/projeto-parceiro.cards.html',
            controller: ProjetoParceiroCardsController,
            bindings: {
                parceiros: '=?',
                allowNew: '<?',
                allowEdit: '<?',
                allowDelete: '<?',
                allowOnlyCountry: '<?',
                onNew: '&?',
                onUpdate: '&?',
                onDelete: '&?'
            }
        });


    /**
     * @ngdoc controller
     * @name components.projeto.projeto-parceiro.projeto-parceiro.cards.controller:ProjetoParceiroCardsController
     *
     * @description
     *
     * It has the logic behind the component
     *
     */
    function ProjetoParceiroCardsController() {

        //An array with Ids of all parceiros that are being edited
        var _allowParceirosEdit = [];
        var vm = this;


        //Public API
        vm.cancelEdit = cancelEdit;
        vm.cancelNew = cancelNew;
        vm.edit = edit;
        vm.update = update;
        vm.saveNew = saveNew;
        vm.indexEditing = indexEditing;

        
        /**
        * @ngdoc function
        * @name cancelEdit
        * @methodOf components.projeto.projeto-parceiro.projeto-parceiro.cards.controller:ProjetoParceiroCardsController
        * @param {object} parceiro It receives the partner that has been edited and was cancelled by the user. 
        *
        * @description
        *
        * This function removes the partner that has been edited and was cancelled by the user from the list of partners being edited.
        */
        function cancelEdit(parceiro) {
            _allowParceirosEdit.splice(_allowParceirosEdit.indexOf(parceiro), 1);
        }

        /**
        * @ngdoc function
        * @name cancelNew
        * @methodOf components.projeto.projeto-parceiro.projeto-parceiro.cards.controller:ProjetoParceiroCardsController
        *
        * @description
        *
        * When the user click on new partner it sets a variable 'newPartner' to true. When it is canceled this function clear this variable setting it to 'undefined' again.
        */
        function cancelNew() {
            vm.newPartner = undefined;
        }

        /**
        * @ngdoc function
        * @name edit
        * @methodOf components.projeto.projeto-parceiro.projeto-parceiro.cards.controller:ProjetoParceiroCardsController
        * @param {object} parceiro It receives the partner that should be edited
        *
        * @description
        *
        * This function receives the partner that should be edited and add it to the list of partners been edited.
        */
        function edit(parceiro) {
            if (parceiro != undefined) {
                _allowParceirosEdit.push(parceiro);
            }
        }

        /**
        * @ngdoc function
        * @name saveNew
        * @methodOf components.projeto.projeto-parceiro.projeto-parceiro.cards.controller:ProjetoParceiroCardsController
        * @param {object} parceiro It receives the partner that should be saved
        *
        * @description
        *
        * This function receives the partner that should be saved and check if the user has passed an output parameter: 'onSave', if so it sends the information.
        * It also closes the card with the new form
        */
        function saveNew(parceiro) {
            //If there is a function to save the data call it
            if (vm.onNew !== undefined) {
                vm.onNew({ parceiro: parceiro });
            }
            //Clear new partner after sending it to save
            vm.newPartner = undefined; 
        }

        /**
        * @ngdoc function
        * @name update
        * @methodOf components.projeto.projeto-parceiro.projeto-parceiro.cards.controller:ProjetoParceiroCardsController
        * @param {object} parceiro It receives the partner that should be updated
        *
        * @description
        *
        * This function receives the partner that should be updated and check if the user has passed an output parameter: 'onUpdate', if so it sends the information.
        * It also closes the card with the new form
        */
        function update(parceiro, index) {

            //If there is a function to save the data call it
            if (vm.onUpdate !== undefined) {
                vm.onUpdate({ parceiro: parceiro });

                //Clear editing partner after sending it to update
                _allowParceirosEdit.splice(index, 1);
            }

        }


        /**
        * @ngdoc function
        * @name isEditing
        * @methodOf components.projeto.projeto-parceiro.projeto-parceiro.cards.controller:ProjetoParceiroCardsController
        * @param {object} parceiro It receives the partner that should be checked if it is being edited.
        * @returns {boolean} It returns true of false, based on the information if the partner that was is being checked is marked as being edited or not
        * @description
        *
        * This function check if the passed partner is in the edited list.
        */
        function indexEditing(parceiro) {

            return _allowParceirosEdit.indexOf(parceiro) 
        }
   
    }
})();