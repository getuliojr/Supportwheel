﻿(function () {
    'use strict';

    /**
     * @ngdoc overview
     * @name components.projeto.projeto-parceiro
     * @description
     *
     * # Components of Projeto-Parceiro #
     *
     * Below is a list of the components that are used in projeto-parceiro. Click on each one for more information:
     *    
     * - {@link components.projeto.projeto-parceiro.projeto-parceiro.cards projeto-parceiro.cards}
     * - {@link components.projeto.projeto-parceiro.projeto-parceiro.form projeto-parceiro.form}
     * - {@link components.projeto.projeto-parceiro.projeto-parceiro-instituicao.chip projeto-parceiro-instituicao.chip}
     * - {@link components.projeto.projeto-parceiro.projeto-parceiro.view projeto-parceiro.view}
     *     
     */
    angular
        .module('components.projeto.projeto-parceiro', [
            'components.projeto.projeto-parceiro.projeto-parceiro.cards',
            'components.projeto.projeto-parceiro.projeto-parceiro.form',
            'components.projeto.projeto-parceiro.projeto-parceiro-instituicao.chip',
            'components.projeto.projeto-parceiro.projeto-parceiro.view'
        ]);

})();

