﻿(function () {

    'use strict';

    /**
    * @ngdoc overview
    * @name components.projeto.projeto.view
    * 
    * @description
    *
    * # abcProjetoView - Component #
    *
    */
    angular
        .module('components.projeto.projeto.view', [
            'shared.services.factory.handleException',
            'shared.services.service.culture',
            'shared.services.service.projeto',
            'shared.services.service.viewstate',
            'shared.services.service.notification',
            'shared.services.service.projetoParceiro',
            'shared.services.service.projetoSubsetor',
            'shared.services.service.subsetor'
        ])


     /**
     * @ngdoc directive
     * @name components.projeto.projeto.view.directive:abcProjetoView
     * 
     * @restrict 'E'
     * 
     * @param {int=} id Id of a project to be loaded
     * 
     * @description
     *
     * # projetoView - Component #
     *
     * This component is responsible to render a form with all valued of a project to be viewed
     *
     */
    .component('abcProjetoView', {
        templateUrl: 'app/components/projeto/projeto.view/projeto.view.html',
        controller: ProjetoViewController,
        bindings: {
            id:"<?"
        }
    });


    //Inject Dependencies
    ProjetoViewController.$inject = ['handleExceptionFactory', 'viewstateService', 'notificationService', 'subsetorService',
        'cultureService', 'projetoService', 'projetoSubsetorService', 'projetoParceiroService', '$scope', '$location'];


    /**
     * @ngdoc controller
     * @name components.projeto.projeto.view.controller:ProjetoViewController
     *
     * @requires shared.services.service.service:projetoParceiroInstituicao
     * @requires shared.services.factory.service:handleException
     *
     * @description
     *
     * It has the logic behind the component
     *
     */
    function ProjetoViewController(handleExceptionFactory, viewstateService, notificationService, subsetorService,
        cultureService, projetoService, projetoSubsetorService, projetoParceiroService, $scope, $location) {

        var vm = this;

        
        //Init component
        vm.$onInit = init;
       
        vm.desabilitaTipoParceiroOrganismo = desabilitaTipoParceiroOrganismo;


        /**
        * @ngdoc function
        * @name carregarProjeto
        * @methodOf  components.projeto.projeto.form.controller:ProjetoFormController
        * @private
        *
        * @description
        *
        * This is a private function that is responsable to load the data of the project
        */
        function carregarProjeto(id) {
            //Load the data of the project
            if (id != undefined) {
                projetoService
                    .load({ intIdProjeto: id })
                    .then(function (data) {
                        //Se não existir, avisa.
                        if (data.intIdProjeto == undefined) {
                            notificationService.show('error', "GENERAL.ERROR-NOTFOUND");
                        } else {
                            //Carrega dados em memória
                            data.dteInicio = new Date(data.dteInicio);
                            data.dteTermino = new Date(data.dteTermino);
                            vm.data = data;

                            //Atualiza valores de acordo com o cultura escolhida pelo usuário e não do projeto
                            updateListNames();
                        }

                    })
                    .catch(handleExceptionFactory);
            }

        }

        /**
        * @ngdoc function
        * @name init
        * @methodOf  components.projeto.projeto.form.controller:ProjetoFormController
        * @private
        *
        * @description
        *
        * This is a private function that is called when the controller is initialized
        */
        function init() {

            //Load the data of the project
            if (vm.id != undefined) {
                carregarProjeto(vm.id);
            }

            //Listen for changes on instituição
            var projetoEvent = projetoService.listenEvent.both.all(updateData);
            var cultureEvent = cultureService.onCultureChange(updateListNames);

            //Cleanup events when controller is destroyed
            $scope.$on("$destroy", projetoEvent);
            $scope.$on('$destroy', cultureEvent);

            //check if the record the user is viewing has changes and update the screen.
            function updateData(result) {
                if (result.data.intIdProjeto == vm.id) {
                    carregarProjeto(vm.id);
                }                
            }

            
        };


        /**
        * @ngdoc function
        * @name updateListNames
        * @methodOf  components.projeto.projeto.form.controller:ProjetoFormController
        *
        * @description
        *
        * This is private function responsable to update the name of subsetores with the correct culture
        */
        function updateListNames() {
            //If there is setores selected, translate its value to new language
            if (vm.data.projetoSubsetores.length > 0) {
                subsetorService
                    .load({ cache: true, intIdSetor: vm.data.projetoSubsetores[0].intIdSetor, strIdCultura: cultureService.getCulture().culture })
                    .then(function (data) {
                        for (var a = vm.data.projetoSubsetores.length - 1; a >= 0; a--) {
                            var index = _.findIndex(data, { intIdSubsetor: vm.data.projetoSubsetores[a].intIdSubsetor });
                            if (index > -1){
                                vm.data.projetoSubsetores[a] = data[index];
                            }
                        }
                    })
                    .catch(handleExceptionFactory);
            }
        }


        
        /**
        * @ngdoc function
        * @name desabilitaTipoParceiroOrganismo
        * @methodOf  components.projeto.projeto.form.controller:ProjetoFormController
        *
        * @param {int} intIdTipoCooperacao Expect an ID containing the value of the "Tipo de Cooperação"
        *
        * @returns {boolean} It returns true when it show show the type of partner Organismo and false when it doesn´t
        *
        * @description
        *
        * This is responsable to enable or not the selection of a partner of the type international organization depending upon on the 'type of cooperation' selected by the user.
        */
        function desabilitaTipoParceiroOrganismo(intIdTipoCooperacao) {
            //Tri-lateral
            if (intIdTipoCooperacao == 3) {
                return false;
            } else {
                return true;
            }
        }

    }
})();
