﻿(function () {

    'use strict';

    /**
    * @ngdoc overview
    * @name components.projeto.projeto.search
    * 
    * @description
    *
    * # abcProjetoSearch - Component #
    *
    */
    angular
        .module('components.projeto.projeto.search', [
            'shared.services.factory.handleException',
            'shared.services.service.culture',
            'shared.services.service.projeto',
            'shared.services.service.viewstate',
            'shared.services.service.notification'
        ])


     /**
     * @ngdoc directive
     * @name components.projeto.projeto.search.directive:abcProjetoSearch
     * 
     * @restrict 'E'
     * 
     * 
     * @description
     *
     * # projetoSearch - Component #
     *
     * This component is responsible to render a form to filter projects
     *
     */
    .component('abcProjetoSearch', {
        templateUrl: 'app/components/projeto/projeto.search/projeto.search.html',
        controller: ProjetoSearchController,
        bindings: {
            allowEdit : "<?"
        }
    });


    //Inject Dependencies
    ProjetoSearchController.$inject = ['handleExceptionFactory', 'viewstateService', 'notificationService', 
        'cultureService', 'projetoService', '$scope', '$location'];


    /**
     * @ngdoc controller
     * @name components.projeto.projeto.view.controller:ProjetoViewController
     *
     * @requires shared.services.service.service:projetoParceiroInstituicao
     * @requires shared.services.factory.service:handleException
     *
     * @description
     *
     * It has the logic behind the component
     *
     */
    function ProjetoSearchController(handleExceptionFactory, viewstateService, notificationService,
        cultureService, projetoService, $scope, $location) {

        var vm = this;
        //To avoid the data to be destroyed in case of a tab change
        vm.data = viewstateService.getView('SearchProjeto');
        vm.data.projects = vm.data.projects || [];

        
        //Init component
        vm.$onInit = init;
        vm.selectProject = selectProject
        vm.searchProject = searchProject
        vm.onPaginate = onPaginate


        /**
        * @ngdoc function
        * @name init
        * @methodOf  components.projeto.projeto.form.controller:ProjetoFormController
        * @private
        *
        * @description
        *
        * This is a private function that is called when the controller is initialized
        */
        function init() {

            //Configure dataList Component
            vm.config = {
                enableFilter: true,
                enableRowSelection: false,
                columns: [{ field: 'strNomeTipoProjeto', isNumeric: false, displayName: '{{"PROJETO-SEARCH.TYPE-PROJECT" | translate }}' },
                          { field: 'strTituloProjeto', isNumeric: false, displayName: '{{"PROJETO-SEARCH.TITLE" | translate }}' },
                        { field: 'strNomeTipoCooperacao', isNumeric: false, displayName: '{{"PROJETO-SEARCH.TYPE-COOPERATION" | translate }}' }],
                itemMenu: [{
                    name: '{{"PROJETO-SEARCH.SELECT" | translate }}', icon: 'edit', ariaLabel: '{{"PROJETO-SEARCH.SELECT" | translate }}',
                    onClick: vm.selectProject
                }]
            };

            //Configure pagination start values
            vm.data.intPageSize = 15;
            vm.data.intPageNumber = 1;

            //Listen for changes on instituição
            var projetoEvent = projetoService.listenEvent.both.all(updateResult);

            //Cleanup events when controller is destroyed
            $scope.$on("$destroy", projetoEvent);

            //Responsable to change the data entered and selected by the user already to a new culture set.
            function updateResult() {
                //Se já fez uma pesquisa
                if (!!vm.data.searched) {
                    //Refaz para trazer no novo idioma
                    var data = angular.copy(vm.data);
                    data.cache = false;
                    data.applyScope = true;
                    searchProject(data);
                }

            }
        };


        function onPaginate() {
            searchProject(vm.data);
        }

        function selectProject(item) {
            var item = item.item;
            var destination = "/project/";

            if ($location.path().indexOf("/restrita") > -1) {
                destination = "/restrita" + destination;
            }

            if (!!vm.allowEdit && $location.path().indexOf("/restrita") > -1) {
                //Check if the user can really edit the project, since there are projects he is not allowed.
                //If he can redirect to edit, else to view only.
                $location.path(destination + item.intIdProjeto + "/edit");
            } else {
                $location.path(destination + item.intIdProjeto);
            }
        }

        function searchProject(params) {
            var query = angular.copy(params);

            //Get Id of of the Sector from its parent data
            if (query.setor != undefined) {
                query.intIdSetor = query.setor.intIdSetor;
            }

            //remove data that should go back to the server
            delete query.projects;
            delete query.setor;

            //cache query if not set by the user
            if (query.cache == undefined) {
                query.cache = true;
            }

            //Get projects based on the criteria selected
            projetoService
                .load(query)
                .then(function (data) {
                    vm.data.projects = data;
                    vm.data.searched = true;
                    vm.data.intTotalRecords = 0;
                    if (data != undefined && data.length > 0 && data[0].intTotalRecords > 0) {
                        vm.data.intTotalRecords = data[0].intTotalRecords;
                    }
                })
                .catch(handleExceptionFactory);
        }
    }
})();
