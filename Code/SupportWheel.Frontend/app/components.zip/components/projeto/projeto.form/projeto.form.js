﻿(function () {

    'use strict';

    /**
    * @ngdoc overview
    * @name components.projeto.projeto.form
    * 
    * @description
    *
    * # abcProjetoForm - Component #
    *
    */
    angular
        .module('components.projeto.projeto.form', [
            'shared.services.factory.handleException',
            'shared.services.service.culture',
            'shared.services.service.projeto',
            'shared.services.service.viewstate',
            'shared.services.service.notification',
            'shared.services.service.projetoParceiro',
            'shared.services.service.projetoSubsetor',
            'shared.services.service.subsetor'
        ])


     /**
     * @ngdoc directive
     * @name components.projeto.projeto.form.directive:abcProjetoForm
     * 
     * @restrict 'E'
     * 
     * @param {int=} id Id of a project to be loaded
     * 
     * @description
     *
     * # projetoForm - Component #
     *
     * This component is responsible to render a form with all valued of a project, so it can be updated or deleted.
     *
     */
    .component('abcProjetoForm', {
        templateUrl: 'app/components/projeto/projeto.form/projeto.form.html',
        controller: ProjetoFormController,
        bindings: {
            id:"<?"
        }
    });


    //Inject Dependencies
    ProjetoFormController.$inject = ['handleExceptionFactory', 'viewstateService', 'notificationService', 'subsetorService',
        'cultureService', 'projetoService', 'projetoSubsetorService', 'projetoParceiroService', '$scope', '$location'];


    /**
     * @ngdoc controller
     * @name components.projeto.projeto.form.controller:ProjetoFormController
     *
     * @requires shared.services.service.service:projetoParceiroInstituicao
     * @requires shared.services.factory.service:handleException
     *
     * @description
     *
     * It has the logic behind the component
     *
     */
    function ProjetoFormController(handleExceptionFactory, viewstateService, notificationService, subsetorService,
        cultureService, projetoService, projetoSubsetorService, projetoParceiroService, $scope, $location) {

        var vm = this;

        //To avoid the data to be destroyed in case of a tab change
        vm.data = viewstateService.getView('Projeto');
        vm.data.projetoSubsetores = [];
        vm.data.projetoParceiros = [];


        //Init component
        vm.$onInit = init;

        //PUBLIC API
        vm.addSubsetor = addSubsetor;
        vm.removeSubsetor = removeSubsetor;
        vm.addParceiro = addParceiro;
        vm.updateParceiro = updateParceiro;
        vm.removeParceiro = removeParceiro;
        vm.saveProject = saveProject;
        vm.removeProject = removeProject;
        vm.newProject = newProject;
        vm.desabilitaTipoParceiroOrganismo = desabilitaTipoParceiroOrganismo;

        /**
        * @ngdoc function
        * @name init
        * @methodOf  components.projeto.projeto.form.controller:ProjetoFormController
        * @private
        *
        * @description
        *
        * This is a private function that is called when the controller is initialized
        */
        function init() {

            //Load the data of the project
            if (vm.id != undefined) {
                projetoService
                    .load({ intIdProjeto: vm.id })
                    .then(function (data) {
                        if (data.intIdProjeto == undefined) {
                            notificationService.show('error', "GENERAL.ERROR-NOTFOUND");
                            vm.data = viewstateService.newView('Projeto');
                            //Devido a lógica de edição ser diferente de um novo registro, redireciona para cair em uma tela vazia para inclusão.
                            $location.path("restrita/project");
                        } else {
                            //Carrega dados em memória
                            data.dteInicio = new Date(data.dteInicio);
                            data.dteTermino = new Date(data.dteTermino);
                            vm.data = data;

                            //Atualiza valores de acordo com o cultura escolhida pelo usuário e não do projeto
                            updateListNames();
                        }
                    })
                    .catch(handleExceptionFactory);
            }

            //Listen for culture Changes to update the value in the correct language
            var cultureEvent = cultureService.onCultureChange(updateListNames);
            $scope.$on('$destroy', cultureEvent);

            //Responsable to change the data entered and selected by the user already to a new culture set.
            function updateListNames() {
                //If there is setores selected, translate its value to new language
                if (vm.data.projetoSubsetores.length > 0) {
                    subsetorService
                        .load({ cache: true, intIdSetor: vm.data.projetoSubsetores[0].intIdSetor, strIdCultura: cultureService.getCulture().culture })
                        .then(function (data) {
                            for (var a = vm.data.projetoSubsetores.length - 1; a >= 0; a--) {
                                var index = _.findIndex(data, { intIdSubsetor: vm.data.projetoSubsetores[a].intIdSubsetor });
                                if (index > -1) {
                                    //Remapeia os valores referentes a nomes
                                    vm.data.projetoSubsetores[a].strNomeSetor = data[index].strNomeSetor;
                                    vm.data.projetoSubsetores[a].strNomeSubsetor = data[index].strNomeSubsetor;
                                }
                            }
                        })
                        .catch(handleExceptionFactory);
                }
            }
        };


        
        /**
        * @ngdoc function
        * @name desabilitaTipoParceiroOrganismo
        * @methodOf  components.projeto.projeto.form.controller:ProjetoFormController
        *
        * @param {int} intIdTipoCooperacao Expect an ID containing the value of the "Tipo de Cooperação"
        *
        * @returns {boolean} It returns true when it show show the type of partner Organismo and false when it doesn´t
        *
        * @description
        *
        * This is responsable to enable or not the selection of a partner of the type international organization depending upon on the 'type of cooperation' selected by the user.
        */
        function desabilitaTipoParceiroOrganismo(intIdTipoCooperacao) {
            //Tri-lateral
            if (intIdTipoCooperacao == 3) {
                return false;
            } else {
                return true;
            }
        }

        /**
        * @ngdoc function
        * @name saveSubsetor
        * @methodOf  components.projeto.projeto.form.controller:ProjetoFormController
        * @param {object} subsetor Expect an object of the new subsetor that should be added to the list
        *
        * @description
        *
        * This is responsable to add a new subsetor to the list. If it is already on the list it will show an error and will not add. If not it will try to save to database first
        */
        function addSubsetor (subsetor) {
            //check if item is not in the list yet
            if (_.findIndex(vm.data.projetoSubsetores, { intIdSubsetor: subsetor.intIdSubsetor }) == -1) {
                //Adds Id of the project
                subsetor.intIdProjeto = vm.data.intIdProjeto;
                //Save to database
                projetoSubsetorService
                    .save(subsetor)
                    .then(function (result) {
                        //Add new item to the list
                        subsetor.intIdProjetoSubsetor = result.intIdProjetoSubsetor;
                        vm.data.projetoSubsetores.push(subsetor);

                        //Clean selected item
                        vm.subsetor = undefined;
                    })
                    .catch(handleExceptionFactory);
            } else {
                notificationService.show('warning', "PROJETO-FORM.EXISTING-SUBSETOR");
            }
        }

        /**
        * @ngdoc function
        * @name removeSubsetor
        * @methodOf  components.projeto.projeto.form.controller:ProjetoFormController
        * @param {object} subsetor Expect an object of the subsetor that should be removed from the list. Tries to delete from the database first.
        *
        * @description
        *
        * This is responsable to remove a subsetor from the list. 
        */
        function removeSubsetor(item) {
            if (item != undefined) {
                projetoSubsetorService
                    .remove(item)
                    .then(function (result) {
                        var index = _.findIndex(vm.data.projetoSubsetores, item);
                        if (index > -1) {
                            vm.data.projetoSubsetores.splice(index, 1);
                            notificationService.show('success', "PROJETO-FORM.REMOVED-ITEM");
                        }
                    })
                    .catch(handleExceptionFactory);
            } else {
                notificationService.show('warning', "PROJETO-FORM.NO-ITEM-TO-DELETE");
            }
        }

        /**
        * @ngdoc function
        * @name addParceiro
        * @methodOf  components.projeto.projeto.form.controller:ProjetoFormController
        * @param {object} item Expect an object of the new partner that should be added to the list
        *
        * @description
        *
        * This is responsable to add a new partner to the list. If it is already on the list it will show an error and will not add.
        */
        function addParceiro(item) {
            //check if item is not in the list yet
            var index = undefined;
            if (item.intIdPais != undefined) {
                index = _.findIndex(vm.data.projetoParceiros, { intIdPais: item.intIdPais })
            } else {
                index = _.findIndex(vm.data.projetoParceiros, { intIdOrganismoInternacional: item.intIdOrganismoInternacional })
            }
            if ( index == -1) {
                //Add to database
                item.intIdProjeto = vm.data.intIdProjeto;
                projetoParceiroService
                   .save(item)
                   .then(function (result) {
                       //Add new item to the list
                       item.intIdProjetoParceiro = result.intIdProjetoParceiro;
                       vm.data.projetoParceiros.push(item);
                       notificationService.show('success', "PROJETO-FORM.SAVED-ITEM");
                   })
                   .catch(handleExceptionFactory);
            } else {
                notificationService.show('warning', "PROJETO-FORM.EXISTING-PARCEIRO");
            }
        }

        /**
        * @ngdoc function
        * @name updateParceiro
        * @methodOf  components.projeto.projeto.form.controller:ProjetoFormController
        * @param {object} item Expect an object of the partner that should be updated in the list
        *
        * @description
        *
        * This is responsable to update the values of a partner that has already been added. 
        */
        function updateParceiro(parceiro) {
            //check if item is not in the list yet
            var index = -1;
            if (parceiro.intIdPais != undefined) {
                index = _.findIndex(vm.data.projetoParceiros, { intIdPais: parceiro.intIdPais })
            } else {
                index = _.findIndex(vm.data.projetoParceiros, { intIdOrganismoInternacional: parceiro.intIdOrganismoInternacional })
            }
            if (index == -1) {
                notificationService.show('warning', "PROJETO-FORM.NO-PARCEIRO");
            } else {
                //Update to Database 
                projetoParceiroService
                   .save(parceiro)
                   .then(function (result) {
                       //Update Item in the List
                       vm.data.projetoParceiros[index] = parceiro;
                       notificationService.show('success', "PROJETO-FORM.SAVED-ITEM");
                   })
                   .catch(handleExceptionFactory);
            }
        }


        /**
        * @ngdoc function
        * @name removeParceiro
        * @methodOf  components.projeto.projeto.form.controller:ProjetoFormController
        * @param {object} item Expect an object of the partner that should be removed to the list
        *
        * @description
        *
        * This is responsable to remove a partner from the list. 
        */
        function removeParceiro(item) {
            if (item != undefined) {
                projetoParceiroService
                   .remove(item)
                   .then(function (result) {
                       var index = _.findIndex(vm.data.projetoParceiros, item);
                       if (index > -1) {
                           vm.data.projetoParceiros.splice(index, 1);
                           notificationService.show('success', "PROJETO-FORM.REMOVED-ITEM");
                       }
                   })
                   .catch(handleExceptionFactory);
            } else {
                notificationService.show('warning', "PROJETO-FORM.NO-ITEM-TO-DELETE");
            }
        }

        /**
        * @ngdoc function
        * @name saveProject
        * @methodOf  components.projeto.projeto.form.controller:ProjetoFormController
        * @param {object} project Expect an object of the data of the project that should be saved
        *
        * @description
        *
        * This is responsable to save the project to the database.
        */
        function saveProject(project) {
            var successCB = function (result) {
                notificationService.show('success', "GENERAL.SAVED-SUCCESSFULLY");
            }

            projetoService.save(project).then(successCB, handleExceptionFactory);
        }

        /**
       * @ngdoc function
       * @name removeProject
       * @methodOf  components.projeto.projeto.form.controller:ProjetoFormController
       * @param {int} intIdProjeto Expect an id of the project to be deleted
       *
       * @description
       *
       * This is responsable to remove the project to the database.
       */
        function removeProject(intIdProjeto) {
            var successCB = function (result) {
                notificationService.show('success', "GENERAL.REMOVED-SUCCESSFULLY");
                //Apaga dados que poderiam existir na view em memória
                viewstateService.newView('Projeto');
                $location.path("restrita/project");
            }

            projetoService.remove({ intIdProjeto: intIdProjeto })
                .then(successCB, handleExceptionFactory);
        }


        /**
        * @ngdoc function
        * @name newInstituicao
        * @methodOf  components.projeto.projeto.form.controller:ProjetoFormController
        *
        * @description
        *
        * This is responsable to redirect the user to a new form
        */
        function newProject() {
            viewstateService.newView('Projeto');
            $location.path("restrita/project");
        }
    }
})();
