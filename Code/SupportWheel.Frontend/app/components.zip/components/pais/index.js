﻿(function () {
    'use strict';

    angular
        .module('components.pais', [
            'components.pais.paisSelect'

    ]);

})();

