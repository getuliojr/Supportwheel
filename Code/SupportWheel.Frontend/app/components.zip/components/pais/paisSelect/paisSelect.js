﻿(function () {

    'use strict';

    /**
    * @ngdoc overview
    * @name components.pais.paisSelect
     * 
    * @description
    *
    * # abcPaisSelect - Component #
    * 
    * This component is responsible to render a select list with autocomplete that will apply on all items
    * of type 'Country'. It is also responsible to change the values based on the current culture or if the
    * Id of the 'Geographic Area' changes.
    *
    */
    angular
        .module('components.pais.paisSelect', [
            'shared.services.service.pais',
            'shared.services.service.culture',
            'shared.services.factory.handleException'
        ])

        /**
        * @ngdoc directive
        * @name components.pais.paisSelect.directive:abcPaisSelect
        * 
        * @restrict 'E'
        * 
        * @param {int=} idAreaGeografica The Id of a Geografic Area. It will filter the coutries based on this information. 
        * @param {object=} pais An object containing at least a property of 'intIdPais' that should be selected. When the user selects an item it will output in this property.
        * @param {boolean=} required Sets if the controller is required or not when submitting a form.
        * @param {boolean=} cache Sets if the controller should cache the data. Defaults to true if not set. It need to be set to false to not cache
        * @param {boolean=} disabled Sets if the controller should be disabled or not.
        * 
        * @description
        *
        * # abcPaisSelect - Component #
        *
        * This component is responsible to render a select list with autocomplete that will apply on all items
        * of type 'Country'. It is also responsible to change the values based on the current culture or if the
        * Id of the 'Geographic Area' changes.
        *
        */
        .component('abcPaisSelect', {
            templateUrl: 'app/components/pais/paisSelect/paisSelect.html',
            controller: PaisSelectController,
            bindings: {
                idAreaGeografica: '<',
                pais: '=?',
                required: '<',
                cache: '<',
                disabled: '<'
            }
        });




    //Inject Dependencies
    PaisSelectController.$inject = ['paisService', 'cultureService', '$scope', 'handleExceptionFactory'];

    /**
     * @ngdoc controller
     * @name components.pais.paisSelect.controller:PaisSelectController
     *
     * @requires shared.services.service.service:pais
     * @requires shared.services.service.service:culture
     * @requires shared.services.factory.service:handleException
     *
     * @description
     *
     * It has the logic behind the component
     *
     */
    function PaisSelectController(paisService, cultureService, $scope, handleExceptionFactory) {

        var vm = this;

        //Default value for cache
        if (vm.cache === undefined) { vm.cache = true};
        vm.paises = [];

        //Public API
        vm.selectedItemChange = selectedItemChange;

        

        //Init the controller
        init();

        /**
        * @ngdoc function
        * @name init
        * @methodOf components.pais.paisSelect.controller:PaisSelectController
        *
        * @description
        *
        * This is a private function that is called when the controller is initialized and everytime an item 
        * or culture is changed
        * 
        */
        function init() {

            var queryParams = { strIdCultura: cultureService.getCulture().culture, cache: vm.cache };

            //If the user has set an ID of a Geografic Area, filter the data
            if (!!vm.idAreaGeografica) {
                queryParams.intIdAreaGeografica = vm.idAreaGeografica;
            }

            //Loads the country list based on the geographic area and culture
            paisService.load(queryParams)
                .then(successCbLoadPais)
                .catch(handleExceptionFactory);
           

            function successCbLoadPais(data) {

                //Make the data available to the controller
                vm.paises = data;

                //Sets the selected item right based on the culture loaded
                if (!!vm.pais && !!vm.pais.intIdPais) {
                    var index = _.findIndex(vm.paises, { intIdPais: vm.pais.intIdPais });
                    if (index > -1) {
                        //Be sure country has completed information
                        vm.pais = vm.paises[index];

                        //Selects item in the list
                        vm.selectedItem = vm.paises[index];
                    }
                }
            }
        }

        //Listen for culture Changes to update the value in the correct language
        var cultureEvent = cultureService.onCultureChange(init);
        $scope.$on('$destroy', cultureEvent);

        //Watch for changes in the id or required parameters that has been passed
        $scope.$watch(function () {
            var intIdPais = undefined;
            if (!!vm.pais && !!vm.pais.intIdPais) {
                intIdPais = vm.pais.intIdPais;
            }
            //What is been watched
            return { idAreaGeografica: vm.idAreaGeografica, intIdPais: intIdPais, required: vm.required };
        }, function (newValue, oldValue) {
            // Check if value has changes
            if (newValue === oldValue) {
                return;
            }

            //If geographic area has changed or country has been cleared
            if ((newValue.idAreaGeografica !== oldValue.idAreaGeografica && oldValue.idAreaGeografica !== undefined) ||
                (newValue.intIdPais === undefined && oldValue.intIdPais !== undefined)) {
                vm.pais = undefined;
                vm.searchText = undefined;
            }

            //When values changes, init the controller again
            init();
        }, true);


        /**
        * @ngdoc function
        * @name selectedItemChange
        * @methodOf components.pais.paisSelect.controller:PaisSelectController
        *
        * @param {object=} item An object with the item, 'Pais', that has changed
        * @param {reference=} ctrl A reference to the controller, so it can set if it is required or not.
        * 
        * @description
        *
        * Everytime a user changes the selected value this item check if the value is different from the one
        * initial set and if are, update the parameter 'pais'.
        * It also sets required message based if the component is required or not
        */
        function selectedItemChange(item, ctrl) {
            if (!!item) {
                //Item changed
                if (vm.pais === undefined || vm.pais.intIdPais !== item.intIdPais) {
                    vm.pais = item;
                }
                //Set requiredError to not show
                if (!!vm.required) {
                    ctrl.$setValidity("required", true);
                }
            } else {
                //clear value
                vm.pais = undefined;

                //set required error to show
                if (!!vm.required) {
                    ctrl.$setValidity("required", false);
                }
            }
        }

    }
})();





