﻿describe('Component.pais: paisSelect', function () {

    //Variable for itens that are going to be used in the tests
    var scope, controller, componentName, componentElement, $componentController, cultureService, $compile, $httpBackend, mockHandleExceptionFactory, handleExceptionFactory;

    //Load Module to be Tested
    //Allows to check if the module handleExceptionFactory has been called
    beforeEach(module('components.pais.paisSelect', 'templates', function ($provide) {
        $provide.decorator('handleExceptionFactory', function ($delegate) {
            mockHandleExceptionFactory = jasmine.createSpy('handleExceptionFactory', $delegate).and.callThrough();
            return mockHandleExceptionFactory;
        });
    }));

    //Load Services
    beforeEach(module('shared.services.service', 'ngMaterial', 'ngStorage', 'pascalprecht.translate'));

    //Load factories (resource, backend)
    beforeEach(module('shared.services.factory', 'ngResource', 'SignalR'));   

    //Inject Dependencies
    beforeEach(inject(function (_$rootScope_, _$componentController_, _$compile_, _cultureService_, _$httpBackend_, _handleExceptionFactory_) {

        var mockDataPT = [

            { "strIdCultura": "pt-BR", "intIdAreaGeografica": 1, "intIdPais": 1, "strNomePais": "Brasil" },
            { "strIdCultura": "pt-BR", "intIdAreaGeografica": 1, "intIdPais": 2, "strNomePais": "Dinamarca" }
        ];

        var mockDataEN = [
            { "strIdCultura": "en-US", "intIdAreaGeografica": 1, "intIdPais": 1, "strNomePais": "Brazil" },
            { "strIdCultura": "en-US", "intIdAreaGeografica": 1, "intIdPais": 2, "strNomePais": "Danmark" }
        ];

        
        //Create new scope
        scope = _$rootScope_.$new();

        //Configure to always disable cache, required for testing
        scope.cache = false;
        componentName = 'abcPaisSelect';

        //Inject dependencies
        $compile = _$compile_;
        $httpBackend = _$httpBackend_;
        cultureService = _cultureService_;
        handleExceptionFactory = _handleExceptionFactory_;
        $componentController = _$componentController_;


        //Mock htppGet
        $httpBackend.whenGET('/asamap/api/pais?cache=false&strIdCultura=pt-BR').respond(mockDataPT);
        $httpBackend.whenGET('/asamap/api/pais?cache=false&intIdAreaGeografica=1&strIdCultura=pt-BR').respond(mockDataPT);
        $httpBackend.whenGET('/asamap/api/pais?cache=true&strIdCultura=pt-BR').respond(mockDataPT);
        $httpBackend.whenGET('/asamap/api/pais?cache=false&intIdAreaGeografica=2&strIdCultura=pt-BR').respond(mockDataPT);
        $httpBackend.whenGET('/asamap/api/pais?cache=false&strIdCultura=en-US').respond(mockDataEN);

        //Set current culture to pt
        cultureService.setCulture('pt-BR');

        //Create Directive, cache should always be false to test it
        componentElement = '<abc-pais-select cache="cache" id-area-geografica="idAreaGeografica" pais="pais" required="required" disabled="disabled"></abc-pais-select>';
        componentElement = getCompiledElement(componentElement);

    }));

    afterEach(function () {
        $httpBackend.verifyNoOutstandingExpectation();
        $httpBackend.verifyNoOutstandingRequest();
    });

    it('expect template to be replaced', function () {
        expect(componentElement.find('md-autocomplete').attr('md-input-name')).toBe('ddlPais');
    });

    it('expect controller to be defined', function () {
        
        controller = $componentController(componentName, { $scope: scope }, { cache: false });
        $httpBackend.flush();
        scope.$digest();
        expect(controller).toBeDefined();
    });

    it('expect controller to be attached to the scope as $ctrl', function () {
        controller = $componentController(componentName, { $scope: scope }, { cache: false });
        $httpBackend.flush();
        //Check if $ctrl has been set with the controller
        expect(scope.$ctrl).toBe(controller);
    });

    it('expect controller to be initialized', function () {
        
        expect(controller.paises.length).toBe(2);
    });

    it('expect parameter: "pais" to be set', function () {

        controller = componentElement.controller(componentName);

        //Shouldn´t have a value yet
        expect(controller.pais).toBeUndefined();

        //Run digest, setting new values in outer scope
        scope.pais = { intIdPais: 2 };
        $httpBackend.flush();
        scope.$digest();

        expect(controller.pais.intIdPais).toBe(2);

    });

    it('expect parameter: "required" to be set', function () {

        controller = componentElement.controller(componentName);
        
        //Shouldn´t have a value yet
        expect(controller.required).toBeUndefined();

        //Run digest, setting new values in outer scope
        scope.required = false;
        $httpBackend.flush();
        scope.$digest();

        expect(controller.required).toBe(false);

        //Run digest, setting new values in outer scope
        scope.required = true;
        $httpBackend.flush();
        scope.$digest();

        expect(controller.required).toBe(true);

    });

    it('expect parameter: "cache" to be set', function () {

        //Create a new component controller to test when no cache is passed
        controller = $componentController(componentName, { $scope: scope });
        $httpBackend.flush();
        scope.$digest();

        //Check if defaults to true
        expect(controller.cache).toBe(true);

        //Get the controller of the element, to test outer scope values
        controller = componentElement.controller(componentName);
        scope.cache = false;
        //$httpBackend.flush();
        scope.$digest();
        expect(controller.cache).toBe(false);

        //Run digest, check default value
        scope.cache = true;
        scope.$digest();
        expect(controller.cache).toBe(true);

    });

    it('expect parameter: "idAreaGeografica" to be set', function () {
        controller = componentElement.controller(componentName);

        //Shouldn´t have a value yet
        expect(controller.idAreaGeografica).toBeUndefined();

        //Run digest, setting new values in outer scope
        scope.idAreaGeografica = 2;
        $httpBackend.flush();
        scope.$digest();

        expect(controller.idAreaGeografica).toBe(2);

    });

    it('expect parameter: "disabled" to be set', function () {
        controller = componentElement.controller(componentName);
        expect(controller.disabled).toBeUndefined();


        scope.disabled = false;
        scope.$digest();
        expect(controller.disabled).toBe(false);

        //Run digest, setting new values in outer scope
        scope.disabled = true;
        scope.$digest();
        expect(controller.disabled).toBe(true);

    });

    it('expect parameter: "pais" to configure selected value in the list', function () {

        controller = componentElement.controller(componentName);
        scope.pais = { intIdPais: 1 };
        $httpBackend.flush();
        scope.$digest();
        expect(controller.selectedItem.strNomePais).toBe('Brasil');

        //Change culture to english
        cultureService.setCulture('en-US');
        scope.pais = { intIdPais: 2 };
        $httpBackend.flush();
        scope.$digest();
        expect(controller.selectedItem.strNomePais).toBe('Danmark');

    });

    it('expect parameter: "pais" to be cleared when "idAreaGeografica" is cleared', function () {

        controller = componentElement.controller(componentName);
        //Shouldn´t have a value yet
        expect(controller.idAreaGeografica).toBeUndefined();
        expect(controller.pais).toBeUndefined();

        scope.idAreaGeografica = 1;
        scope.pais = { intIdPais: 2 };

        //Run digest, setting new values in outer scope
        $httpBackend.flush();
        scope.$digest();

        //Should have set values
        expect(controller.idAreaGeografica).toBe(1);
        expect(controller.pais.intIdPais).toBe(2);

        //Now we clear idAreaGeografica
        scope.idAreaGeografica = undefined;
        //Run digest, setting new values in outer scope
        $httpBackend.flush();
        scope.$digest();

        expect(controller.idAreaGeografica).toBeUndefined();
        expect(controller.pais).toBeUndefined();

    });

    it('expect parameter: "pais" to be cleared when "idAreaGeografica" is changed', function () {

        controller = componentElement.controller(componentName);

        //Shouldn´t have a value yet
        expect(controller.idAreaGeografica).toBeUndefined();
        expect(controller.pais).toBeUndefined();

        //Run digest, setting new values in outer scope
        scope.idAreaGeografica = 1;
        scope.pais = { intIdPais: 1 };
        $httpBackend.flush();
        scope.$digest();

        //Should have set values
        expect(controller.idAreaGeografica).toBe(1);
        expect(controller.pais.intIdPais).toBe(1);

        //Run digest, setting new values in outer scope
        scope.idAreaGeografica = 2;
        $httpBackend.flush();
        scope.$digest();

        //Should both be undefined
        expect(controller.idAreaGeografica).toBe(2);
        expect(controller.pais).toBeUndefined();


    });

    it('expect parameter: "pais" to be cleared when "pais" is cleared', function () {

        controller = componentElement.controller(componentName);
        scope.idAreaGeografica = 1;
        scope.pais = { intIdPais: 1 };
        

        //Shouldn´t have a value yet
        expect(controller.idAreaGeografica).toBeUndefined();
        expect(controller.pais).toBeUndefined();

        //Run digest, setting new values in outer scope
        $httpBackend.flush();
        scope.$digest();

        //Should have set values
        expect(controller.idAreaGeografica).toBe(1);
        expect(controller.pais.intIdPais).toBe(1);

        scope.pais = undefined;
        //Run digest, setting new values in outer scope
        $httpBackend.flush();
        scope.$digest();

        //Should both be undefined
        expect(controller.idAreaGeografica).toBe(1);
        expect(controller.pais).toBeUndefined();
        expect(controller.searchText).toBeUndefined();

    });

    it('expect handleExceptionFactory to have been called on failing to load data', function() {
        //To force the controller to init and respond with an error
        $httpBackend.whenGET('/asamap/api/pais?cache=false&strIdCultura=es-ES').respond(500);

        cultureService.setCulture('es-ES');
        $httpBackend.flush();
        scope.$digest();
        //Espera ter caido em exceção
        expect(handleExceptionFactory).toHaveBeenCalled();
    });

    //Helper Function
    function getCompiledElement(el){
        var element = angular.element("<body>" + el + "</body");
        var compiledElement = $compile(element)(scope);
        //On init of the controller has a httpGET so flush it already       
        $httpBackend.flush();
        scope.$digest();       
        return compiledElement;
    }

});