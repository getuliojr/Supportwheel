﻿(function () {
    'use strict';

    angular
        .module('components.setor', [
            'components.setor.setorSelect'

    ]);

})();

