﻿describe('Component.setor: setorSelect', function () {

    //Variable for itens that are going to be used in the tests
    var $compile, directive, controllerAs, directiveName, isolateScope, cultureService, $httpBackend, mockHandleExceptionFactory;

    //Load Module to be Tested
    //Allows to check if the module handleExceptionFactory has been called
    beforeEach(module('components.setor.setorSelect', 'templates', function ($provide) {
        $provide.decorator('handleExceptionFactory', function ($delegate) {
            mockHandleExceptionFactory = jasmine.createSpy('handleExceptionFactory', $delegate).and.callThrough();
            return mockHandleExceptionFactory;
        });
    }));

    //Load Services
    beforeEach(module('shared.services.service', 'ngStorage', 'ngMaterial', 'pascalprecht.translate'));

    //Load factories (resource, backend)
    beforeEach(module('shared.services.factory', 'ngResource', 'SignalR'));

   

    //Inject Dependencies
    beforeEach(inject(function (_$rootScope_, _$controller_, _$compile_, _cultureService_, _$httpBackend_, _handleExceptionFactory_) {

        var mockDataPT = [{ "intIdSetor": 1, "strIdCultura": "pt-BR", "strNomeSetor": "Administração Pública" },
                          { "intIdSetor": 2, "strIdCultura": "pt-BR", "strNomeSetor": "Agricultura" }];

        var mockDataEN = [{ "intIdSetor": 1, "strIdCultura": "en-US", "strNomeSetor": "Public Administration" },
                          { "intIdSetor": 2, "strIdCultura": "en-US", "strNomeSetor": "Agriculture" }];

        
        //Create new scope
        scope = _$rootScope_.$new();

        //Configure to always disable cache, required for testing
        scope.cache = false; 

        //Inject dependencies
        $compile = _$compile_;
        $httpBackend = _$httpBackend_;
        cultureService = _cultureService_;
        handleExceptionFactory = _handleExceptionFactory_; 


        //Mock htppGet
        $httpBackend.whenGET('/asamap/api/setor?strIdCultura=pt-BR').respond(mockDataPT);
        $httpBackend.whenGET('/asamap/api/setor?strIdCultura=en-US').respond(mockDataEN);
        $httpBackend.whenGET('/asamap/api/setor?strIdCultura=es-ES').respond(500);

        //Set current culture to pt
        cultureService.setCulture('pt-BR');

        //Create Directive, cache should always be false to test it
        var directiveElement = '<abc-setor-select cache="cache" setor="setor" disabled="disabled" required="required"></abc-setor-select>';
        directive = getCompiledElement(directiveElement);

        //Other variables
        controllerAs = 'setorSelect';
        directiveName = 'abcSetorSelect';
        isolateScope = directive.isolateScope();

    }));

    afterEach(function () {
        $httpBackend.verifyNoOutstandingExpectation();
        $httpBackend.verifyNoOutstandingRequest();
    });

    it('expect template to be replaced', function () {
        expect(directive.find('md-autocomplete').length).toBe(1);
    });

    it('expect controller to be defined', function () {
        var controller = directive.controller(directiveName);
        expect(controller).toBeDefined();
    });

    it('expect controller to be initialized', function () {
        var controller = directive.controller(directiveName);
        expect(controller.setores.length).toBe(2);
    });

    it('expect controllerAs name to be right', function () {
        expect(isolateScope.hasOwnProperty(controllerAs)).toBeTruthy();
    });

    it('expect parameter: "setor" to be set', function () {
        var setor = { intIdSetor: 2 };
        scope.setor = setor;
        var controller = isolateScope[controllerAs];

        //Shouldn´t have a value yet
        expect(controller.setor).toBeUndefined();

        //Run digest, setting new values in outer scope
        $httpBackend.flush();
        scope.$digest();

        expect(controller.setor.intIdSetor).toBe(2);

    });

    it('expect parameter: "required" to be set', function () {
        var required = false;
        scope.required = required;
        var controller = isolateScope[controllerAs];

        //Shouldn´t have a value yet
        expect(controller.required).toBeUndefined();

        //Run digest, setting new values in outer scope
        $httpBackend.flush();
        scope.$digest();

        expect(controller.required).toBe(required);

    });

    it('expect parameter: "cache" to be set', function () {
        scope.cache = true;
        var controller = isolateScope[controllerAs];

        //Shouldn´t have a value yet
        expect(controller.cache).toBe(false);

        //Run digest, setting new values in outer scope
        scope.$digest();
        expect(controller.cache).toBe(true);

    });

    it('expect parameter: "disabled" to be set', function () {
        scope.disabled = true;
        var controller = isolateScope[controllerAs];

        //Shouldn´t have a value yet
        expect(controller.disabled).toBeUndefined();

        //Run digest, setting new values in outer scope
        scope.$digest();
        expect(controller.disabled).toBe(true);

    });


    it('expect parameter: "setor" to configure selected value in the list', function () {
        var controller = isolateScope[controllerAs];
        scope.setor = { intIdSetor: 1 };
        $httpBackend.flush();
        scope.$digest();
        expect(controller.searchText).toBe('Administração Pública');

        cultureService.setCulture('en-US');
        scope.setor = { intIdSetor: 2 };
        $httpBackend.flush();
        scope.$digest();
        expect(controller.searchText).toBe('Agriculture');

    });

    it('expect handleExceptionFactory to have been called on failing to load data', function () {
        //To force the controller to init and respond with an error
        cultureService.setCulture('es-ES');
        $httpBackend.flush();
        scope.$digest();
        //Espera ter caido em exceção
        expect(handleExceptionFactory).toHaveBeenCalled();
    })

    //Helper Function
    function getCompiledElement(el){
        var element = angular.element("<body>" + el + "</body");
        var compiledElement = $compile(element)(scope);
        //On init of the controller has a httpGET so flush it already
        $httpBackend.flush();
        scope.$digest();       
        return compiledElement;
    }

});