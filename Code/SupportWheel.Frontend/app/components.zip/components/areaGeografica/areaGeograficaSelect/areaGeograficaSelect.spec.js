﻿describe('Component.areaGeografica: areaGeograficaSelect', function () {

    //Variable for itens that are going to be used in the tests
    var $compile, directive, controllerAs, directiveName, isolateScope, cultureService, $httpBackend, mockHandleExceptionFactory;

    //Load Module to be Tested
    //Allows to check if the module handleExceptionFactory has been called
    beforeEach(module('components.areaGeografica.areaGeograficaSelect', 'templates', function ($provide) {
        $provide.decorator('handleExceptionFactory', function ($delegate) {
            mockHandleExceptionFactory = jasmine.createSpy('handleExceptionFactory', $delegate).and.callThrough();
            return mockHandleExceptionFactory;
        });
    }));

    //Load Services
    beforeEach(module('shared.services.service', 'ngStorage', 'ngMaterial', 'pascalprecht.translate'));

    //Load factories (resource, backend)
    beforeEach(module('shared.services.factory', 'ngResource', 'SignalR'));

   

    //Inject Dependencies
    beforeEach(inject(function (_$rootScope_, _$controller_, _$compile_, _cultureService_, _$httpBackend_, _handleExceptionFactory_) {

        var mockDataPT = [{ "intIdAreaGeografica": 1, "strIdCultura": "pt-BR", "strNomeAreaGeografica": "África" },
                      { "intIdAreaGeografica": 2, "strIdCultura": "pt-BR", "strNomeAreaGeografica": "América do Sul" }];

        var mockDataPTCached = [{ "intIdAreaGeografica": 1, "strIdCultura": "pt-BR", "strNomeAreaGeografica": "África" }];

        var mockDataEN = [{ "intIdAreaGeografica": 1, "strIdCultura": "en-US", "strNomeAreaGeografica": "Africa" },
                      { "intIdAreaGeografica": 2, "strIdCultura": "en-US", "strNomeAreaGeografica": "South America" }];

        
        //Create new scope
        scope = _$rootScope_.$new();
        //Configure to always disable cache
        scope.cache = false; 

        //Inject dependencies
        $compile = _$compile_;
        $httpBackend = _$httpBackend_;
        cultureService = _cultureService_;
        handleExceptionFactory = _handleExceptionFactory_;


        //Mock htppGet
        $httpBackend.whenGET('/asamap/api/areaGeografica?strIdCultura=pt-BR').respond(mockDataPT);
        $httpBackend.whenGET('/asamap/api/areaGeografica?cache=true&strIdCultura=pt-BR').respond(mockDataPTCached);
        $httpBackend.whenGET('/asamap/api/areaGeografica?strIdCultura=en-US').respond(mockDataEN);
        $httpBackend.whenGET('/asamap/api/areaGeografica?strIdCultura=es-ES').respond(500);

        //Set current culture to pt
        cultureService.setCulture('pt-BR');

        //Create Directive, cache should always be false to test it
        var directiveElement = '<abc-area-geografica-select cache="cache" id="id" required="required"></abc-area-geografica-select>';
        directive = getCompiledElement(directiveElement);

        //Other variables
        controllerAs = 'areaGeograficaSelect';
        directiveName = 'abcAreaGeograficaSelect';
        isolateScope = directive.isolateScope();

    }));

    afterEach(function () {
        $httpBackend.verifyNoOutstandingExpectation();
        $httpBackend.verifyNoOutstandingRequest();
    });

    it('expect template to be replaced', function () {
        expect(directive.find('md-autocomplete').length).toBe(1);
    });

    it('expect controller to be defined', function () {
        var controller = directive.controller(directiveName);
        expect(controller).toBeDefined();
    });

    it('expect controller to be initialized', function () {
        var controller = directive.controller(directiveName);
        expect(controller.areasGeograficas.length).toBe(2);
    });

    it('expect controllerAs name to be right', function () {
        expect(isolateScope.hasOwnProperty(controllerAs)).toBeTruthy();
    });

    it('expect parameter: "id" to be set', function () {
        var id = 2;
        scope.id = id; 
        var controller = isolateScope[controllerAs];

        //Shouldn´t have a value yet
        expect(controller.id).toBeUndefined();

        //Run digest, setting new values in outer scope
        $httpBackend.flush();
        scope.$digest();

        expect(controller.id).toBe(id);

    });

    it('expect parameter: "required" to be set', function () {
        var required = false;
        scope.required = required;
        var controller = isolateScope[controllerAs];

        //Shouldn´t have a value yet
        expect(controller.required).toBeUndefined();

        //Run digest, setting new values in outer scope
        $httpBackend.flush();
        scope.$digest();

        expect(controller.required).toBe(required);

    });
    
    it('expect parameter: "cache" to be set', function () {
        scope.cache = true;
        var controller = isolateScope[controllerAs];

        //Shouldn´t have a value yet
        expect(controller.cache).toBe(false);

        //Run digest, setting new values in outer scope
        $httpBackend.flush();
        scope.$digest();
        expect(controller.cache).toBe(true);

    });

    it('expect parameter: "cache" to defaults to true', function () {
        scope.cache = undefined;
        $httpBackend.flush();
        scope.$digest();
        var controller = isolateScope[controllerAs];

        //Run digest, setting new values in outer scope
        expect(controller.areasGeograficas.length).toBe(1);

    });

    it('expect parameter: "id" to configure selected value in the list', function () {
        var controller = isolateScope[controllerAs];
        scope.id = 1;
        $httpBackend.flush();
        scope.$digest();
        expect(controller.searchText).toBe('África');

        cultureService.setCulture('en-US');
        scope.id = 2;
        $httpBackend.flush();
        scope.$digest();
        expect(controller.searchText).toBe('South America');

    });

    it('expect handleExceptionFactory to have been called on failing to load data', function () {
        //To force the controller to init and respond with an error
        cultureService.setCulture('es-ES');
        $httpBackend.flush();
        scope.$digest();
        //Espera ter caido em exceção
        expect(handleExceptionFactory).toHaveBeenCalled();
    })

    //Helper Function
    function getCompiledElement(el){
        var element = angular.element("<body>" + el + "</body");
        var compiledElement = $compile(element)(scope);
        //On init of the controller has a httpGET so flush it already
        $httpBackend.flush();
        scope.$digest();       
        return compiledElement;
    }

});