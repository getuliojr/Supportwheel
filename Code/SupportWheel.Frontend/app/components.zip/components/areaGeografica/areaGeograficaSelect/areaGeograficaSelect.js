﻿(function () {

    'use strict';

     /**
     * @ngdoc overview
     * @name components.areaGeografica.areaGeograficaSelect
     * @description
     *
     * # areaGeograficaSelect - Component #
     *
     * This component is responsible to render a select list with autocomplete will all values of the item 'Area Geográfica', it is
     * also responsible to change the values based on the current culture
     *
     * @example
       <pre>
        <abc-area-geografica-select cache="cache" id="id" required="required"></abc-area-geografica-select>
       </pre>
     */
    angular
        .module('components.areaGeografica.areaGeograficaSelect', [
            'shared.services.service.areaGeografica',
            'shared.services.service.culture',
            'shared.services.factory.handleException'
        ])

        .directive('abcAreaGeograficaSelect', areaGeograficaSelectDirective)
        .controller('AreaGeograficaSelectController', AreaGeograficaSelectController);


    /**
     * @ngdoc directive
     * @name components.areaGeografica.areaGeograficaSelect.directive:areaGeograficaSelect
     * @restrict 'E'
     * @param {int=} id The Id of the item that is selected or should be selected. It automatically maps to intIdAreaGeografica
     * @param {boolean=} required Sets if the control is required or not when submitting a form
     * @param {boolean=} cache Sets if the control should cache the data. Defaults to true if not set. It need to be set to false to not cache
     *
     * @description
     *
     * This component will render a select list with all values of 'Area Geográfica' and control the current culture set.
     * The selected item will be available throught the parameterer 'id'
     *
     */
    function areaGeograficaSelectDirective() {
        return {
            restrict: 'E',
            controller: 'AreaGeograficaSelectController',
            templateUrl: 'app/components/areaGeografica/areaGeograficaSelect/areaGeograficaSelect.html',
            controllerAs: 'areaGeograficaSelect',
            scope: {},
            bindToController: {
                id: '=',
                required: '=',
                cache: '='
            }
        }
    }

    //Inject Dependencies
    AreaGeograficaSelectController.$inject = ['areaGeograficaService', 'cultureService', '$scope', 'handleExceptionFactory'];

    /**
     * @ngdoc controller
     * @name components.areaGeografica.areaGeograficaSelect.controller:AreaGeograficaSelectController
     * @description
     *
     * It has the logic behind the component
     *
     */
    function AreaGeograficaSelectController(areaGeograficaService, cultureService, $scope, handleExceptionFactory) {

        var vm = this;
        vm.areasGeograficas = [];
        vm.selectedItemChange = selectedItemChange;

        init();

        /**
        * @ngdoc function
        * @name init
        * @methodOf components.areaGeografica.areaGeograficaSelect.controller:AreaGeograficaSelectController
        *
        * @description
        *
        * This is a private function that is called when the controller is initialized and everytime an item or culture is changed
        */
        function init() {
            var queryParams = { strIdCultura: cultureService.getCulture().culture };

            //Defaults to true if not set
            if (vm.cache !== false) {
                queryParams.cache = true;
            }

            areaGeograficaService
                .load(queryParams)
                .then(function (data) {
                    vm.areasGeograficas = data;

                    if (!!vm.id) {
                        var index = _.findIndex(vm.areasGeograficas, { intIdAreaGeografica: vm.id });
                        if (index > -1) {
                            vm.selectedItem = vm.areasGeograficas[index];
                        }
                    }
                })
                .catch(handleExceptionFactory);
        }

        //Listen for culture Changes to update the value in the correct language
        var cultureEvent = cultureService.onCultureChange(init);
        $scope.$on('$destroy', cultureEvent);

        //Watch for changes in the id or required parameters that has been passed
        $scope.$watch(function () {
            return { id: vm.id, required: vm.required, cache: vm.cache };
        }, function (newValue, oldValue) {
            // Check if value has changes
            if (newValue === oldValue) {
                return;
            }
            //When values changes, init the controller again
            init();
        }, true);


        /**
        * @ngdoc function
        * @name selectedItemChange
        * @methodOf components.areaGeografica.areaGeograficaSelect.controller:AreaGeograficaSelectController
        *
        * @description
        *
        * Everytime a user changes the selected value this item check if the value is different from the one initial set and if are, update the parameter 'id'.
        * It also sets error messages based if the component is required or not
        */
        function selectedItemChange(item, ctrl) {
            if (!!item) {
                //Item changed
                if (item.intIdAreaGeografica !== vm.id) {
                    vm.id = item.intIdAreaGeografica;
                }
                //Set requiredError to not show
                if (!!vm.required) {
                    ctrl.$setValidity("required", true);
                }
            } else {
                //clear value
                vm.id = undefined;
                //set required error to show
                if (!!vm.required) {
                    ctrl.$setValidity("required", false);
                }
            }
        }

    }
})();