﻿(function () {
    'use strict';

    angular
        .module('components.areaGeografica', [
            'components.areaGeografica.areaGeograficaSelect'

    ]);

})();

