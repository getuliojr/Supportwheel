﻿angular.module('modules.topic', [
     'modules.topic.controllers',
     'modules.topic.services',

])