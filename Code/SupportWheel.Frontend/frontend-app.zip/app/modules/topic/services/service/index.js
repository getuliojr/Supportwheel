﻿(function () {

    'use strict';

    angular.module('modules.topic.services.service', [
        'modules.topic.services.service.topic'
    ]);

})();