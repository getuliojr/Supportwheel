﻿(function () {

    'use strict';

    angular.module('modules.topic.services', [
        'modules.topic.services.service'
    ]);

})();