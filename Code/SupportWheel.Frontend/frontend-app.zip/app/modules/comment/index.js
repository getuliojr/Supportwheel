﻿angular.module('modules.comment', [
    'modules.comment.controllers',
    'modules.comment.services'

])