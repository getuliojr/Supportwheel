﻿angular.module('modules.comment.controllers', [
     'modules.comment.controllers.newComment'

])