﻿(function () {

    'use strict';

    angular.module('modules.comment.services.service', [
        'modules.comment.services.service.comment'
    ]);

})();