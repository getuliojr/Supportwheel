﻿(function () {

    'use strict';

    angular.module('modules.common.services', [
        'modules.common.services.factory',
        'modules.common.services.provider',
        'modules.common.services.service',
        'modules.common.services.value'
    ]);

})();