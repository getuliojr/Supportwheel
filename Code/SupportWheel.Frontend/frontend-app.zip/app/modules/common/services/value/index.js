﻿(function () {

    'use strict';

    angular.module('modules.common.services.value', [
        'modules.common.services.value.constantes'
    ]);

})();