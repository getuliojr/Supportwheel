﻿(function() {

    'use strict';

    //Define o módulo
    angular
        .module('modules.common.controllers', [
            'modules.common.controllers.auth'
        ]);
})();