﻿import template from './app.html';

let appComponent = {
  template,
  restrict: 'E'
};

export default appComponent;