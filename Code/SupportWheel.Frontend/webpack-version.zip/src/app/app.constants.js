﻿const AppConstants = {
    appName: "Nação Digital",
    constEventosDB: {inserted: 1, updated: 2, deleted: 3}
};

export default AppConstants;