﻿//import * as vis from 'ui-router-visualizer';

function AppRun() {


	//...

    //Responsavel por gerar um gráfico de rotas que a aplicação possui
    //vis.visualizer($uiRouter);
};

export default AppRun;