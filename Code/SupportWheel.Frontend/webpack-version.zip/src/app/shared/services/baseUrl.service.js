﻿import angular from 'angular';
import uiRouter from '@uirouter/angularjs';



class BaseUrlService {

    constructor($location) {
        this.$location = $location;
    }

    getBaseUrl() {
        if (this.$location.absUrl().indexOf("http://localhost") != -1)
            return "http://localhost:8080/app/";
        else
            return "/app/";
    }
}

BaseUrlService.$inject = ['$location'];

export default angular
    .module('app.shared.services.baseUrl', [])
    .service('baseUrlService', BaseUrlService)
    .name;