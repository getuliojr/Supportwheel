﻿import angular from 'angular';

//import Example from './example/';


let componentsModule = angular.module('app.components', [
  //Example
  
])
.name;

export default componentsModule;